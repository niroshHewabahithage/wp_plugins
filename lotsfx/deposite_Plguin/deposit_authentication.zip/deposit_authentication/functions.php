<?php

/*
  Plugin Name: Deposit Authentication
  Plugin URI: http://weblankan.com
  Description: Authentication windows before the payment buttons
  Version: 1.0
  Author: Nirosh Randimal
  Author URI: www.linkedin.com/in/nirosh-randimal-331598146
  License: GPL2
 */

global $me_db_version;
global $folder;
global $site_url;
global $uri_segnemt;
global $limit;
global $table_name;
global $ltfx_db_version;

$ltfx_db_version = '1.0.0';
//$folder = 'sliit-sms';
$folder = 'lotsfx';
$uri_segnemt = 5;
$limit = 5;
global $wpdb;
$table_name = $wpdb->prefix . "ltfx_deposite_login";

function _nr_ltfx_deposit_authentication_init() {

    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    global $table_name;
    global $ltfx_db_version;
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
                    `id`  int(11) NOT NULL AUTO_INCREMENT ,
                `password`  varchar(255) NOT NULL ,
                `other`  varchar(255) NOT NULL ,
                 `status`  int(2) ZEROFILL NOT NULL ,
                PRIMARY KEY (`id`)
	) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta($sql);

    add_option('ltfx_db_version', $ltfx_db_version);
}

register_activation_hook(__FILE__, '_nr_ltfx_deposit_authentication_init');
register_activation_hook(__FILE__, '_nr_ltfx_deposit_my_activation_func');

function _nr_ltfx_deposit_my_activation_func() {
    file_put_contents(__DIR__ . '/my_loggg.txt', ob_get_contents());
}

function _nr_ltfx_deposit_authetication_form() {
    wp_enqueue_style('_dj_ltfx-main', plugins_url('assets/css/main.css', __FILE__));
    wp_enqueue_script('_dj_ltfx-authentication-view', plugins_url("assets/js/authetication.js", __FILE__), array('jquery'), 1.1, true);

    // make the ajaxurl var available to the above script
    wp_localize_script('_dj_ltfx-authentication-view', 'the_ajax_script', array('ajaxurl' => admin_url('admin-ajax.php')));

//    include __DIR__ . './inc/ipfinder.php';
//    $country_code = ip_info(null, "Country Code");
    ob_start();
//    $code = get_code($country_code);
    include (__DIR__ . "/template/deposit_view.php");
    return ob_get_clean();
}

add_shortcode('authentication_view', '_nr_ltfx_deposit_authetication_form');

add_action('wp_ajax_nopriv_authen_payment', '_nr_ltfx_authentication');

function _nr_ltfx_authentication() {
    $json = array();
    $passcode_post = "";

    if (isset($_POST['entry_code'])) {
        $passcode_post = $_POST['entry_code'];
    }

    if ($passcode_post != "") {
        global $wpdb;
        global $table_name;
        $row = $wpdb->get_row("SELECT * FROM wp_ltfx_deposite_login WHERE password='" . md5($passcode_post) . "'");
        if ($row) {
            $json['error_code'] = "00";
            $json['msg'] = "Successfully Authenticated";
        } else {
            $json['error_code'] = "ERR";
            $json['msg'] = "Promo Code is Wrong";
        }
    } else {
        $json['error_code'] = "ERR";
        $json['msg'] = "Something Went Wrong With the input Parameters";
    }
    echo json_encode($json);
    exit();
}
