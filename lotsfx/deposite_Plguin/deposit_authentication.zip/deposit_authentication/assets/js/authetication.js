jQuery.noConflict();
(function ($) {
    $(function () {
        $(document).ready(function () {
            $("#id-authenticate-passcode").click(function () {
                var passcode = $("#entry_code").val();
                var isValidation = false;

                if (passcode.trim() !== "" && typeof passcode !== "undefined") {
                    isValidation = true;
                } else {
                    $("._dj_ltfx-error-block").show(500).find("span").html("Please Enter Promo Code to continue");
                    setTimeout(function () {
                        $("._dj_ltfx-error-block").hide(500);
                    }, 6500);
                }

                if (isValidation) {
                    var data = $("#nr_lotsfx_passcode_item").serializeArray();
                    data.push({name: "action", value: "authen_payment"});
                    window.console.warn(data);
                    var set_buttons = "";
                    $("#id-authenticate-passcode").attr({disabled: true}).html("Authenticating...");
                    $.post(the_ajax_script.ajaxurl, data, function (response) {
                        var res = JSON.parse(response);
                        if (res.error_code == "00") {
                            $("._dj_ltfx-error-block").addClass("success").show(500).find("span").html(res.msg);
                            setTimeout(function () {
					//https://lotssolution.com/payment01/
                                $("._dj_ltfx-error-block").hide(500);
                                set_buttons = "</div><div class='col-sm-4'>" +
                                        "<a href='https://www.lotssolution.com/payment/' target='_blank'><button class='btn btn-block btn-danger btn_02' id='direct_pay_button' onlcick='navigate_primary()'type='button'>Visa / Master / Amex</button></a>" +
                                        "</div>" +
                                        "<div class='col-sm-4'>" +
                                       "<a href='https://lotsglobal.com/cashfree/' target='_blank'><button class='btn btn-block btn-danger btn_02' id='razor_pay_button' onlcick='navigate_secondary()'type='button'>Secondary Payment</button></a>" +
                                      "</div>"+
//                                        "<div class='col-sm-4'>"+
//					"<a href='https://heliconmy.com/stripe/' target='_blank'><button class='btn btn-block btn-danger btn_02' id='stripe_button' onlcick='navigate_secondary()'type='button'>International</button></a>" +
//					"</div>" +
                                    "<div class='col-sm-4'>" +
					"<a href='https://lotsglobal.com/stripe/' target='_blank'><button class='btn btn-block btn-danger btn_02' id='stripe_button' onlcick='navigate_secondary()'type='button'>S PAY</button></a>" +
                                    "</div>" +
                                    "<div class='col-sm-4'>" +
                                    "<a href='https://lotsglobal.com/paynimo/' target='_blank'><button class='btn btn-block btn-danger btn_02' id='stripe_button' onlcick='navigate_secondary()'type='button'>PAYNIMO</button></a>" +
                                    "</div>" +
                                    "<div class='col-sm-4'>" +
                                    "</div>";
//                                        "<div class='col-sm-4'>" +
//                                        "<form name='pay_with_globepay' id='pay_with_globepay' action='https://www.globepayinc.com/make_payment.php' target='_blank' method='post'>" +
//                                        "<input type='hidden' name='cancel_url' id='cancel_url' value='https://www.lotsfx.com/globe_cancle.html' />" +
//                                        "<input type='hidden' name='success_url' id='success_url' value='https://www.lotsfx.com/globe_success.html'  />" +
//                                        "<input type='hidden' name='custom' id='custom' value='soap_111'  />" +
//                                        "<input type='hidden' name='button_type' id='button_type' value='buy_now' />" +
//                                        "<input type='hidden' name='item_name' id='item_name' value='for business'  />" +
//                                        "<input type='hidden' name='item_id' id='item_id' value='22'  />" +
//                                        "<input type='hidden' name='price' id='price' value='1'  />" +
//                                        "<input type='hidden' name='quantity' id='quantity' value='1'  />" +
//                                        "<input type='hidden' name='postage' id='postage' value=''  />" +
//                                        "<input type='hidden' name='tax_rate' id='tax_rate' value=''  />" +
//                                        "<input type='hidden' name='callback_url' id='callback_url' value='callback_url'  />" +
//                                        "<input type='hidden' name='currency' id='currency' value='USD'  />" +
//                                        "<input type='hidden' name='email_address' id='email_address' value='deposit@lotsfx.com'  />" +
//                                        "<button class='btn btn-block btn-danger btn_02' type='submit'>Pay With Lotsfx</button>" +
//                                        "</form>" +
//                                        "</div>";


                                $("#set_buttons").html(set_buttons);
                            }, 3500);
                        } else {
                            $("._dj_ltfx-error-block").show(500).find("span").html(res.msg);
                            setTimeout(function () {
                                $("._dj_ltfx-error-block").hide(500);
                                document.getElementById("nr_lotsfx_passcode_item").reset();
                                $("#id-authenticate-passcode").attr({disabled: false}).html("Submit Code");
                            }, 3500);
                        }
                    });
                }
            });


        });

    });
})(jQuery);
