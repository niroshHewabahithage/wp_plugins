jQuery.noConflict();
(function ($) {
    $(function () {
        $(document).ready(function () {  
          $("#id-authenticate-passcode").click(function () {
                var passcode = $("#entry_code").val();
                var isValidation = false;

                if (passcode.trim() !== "" && typeof passcode !== "undefined") {
                    isValidation = true;
                } else {
                    $("._dj_ltfx-error-block").show(500).find("span").html("Please Enter Promo Code to continue");
                    setTimeout(function () {
                        $("._dj_ltfx-error-block").hide(500);
                    }, 6500);
                }

                if (isValidation) {
                    var data = $("#nr_lotsfx_passcode_item").serializeArray();
                    data.push({name: "action", value: "authen_payment"});
                    window.console.warn(data);
                    var set_buttons = "";
                    $("#id-authenticate-passcode").attr({disabled: true}).html("Authenticating...");
                    $.post(the_ajax_script.ajaxurl, data, function (response) {
                        var res = JSON.parse(response);
                        if (res.error_code == "00") {
                            $("._dj_ltfx-error-block").addClass("success").show(500).find("span").html(res.msg);
                            setTimeout(function () {
                                $("._dj_ltfx-error-block").hide(500);
                                set_buttons = "<div class='col-sm-4'>" +
                                        "<a href='https://www.lotssolution.com/payment/' target='_blank'><button class='btn btn-block btn-danger btn_02' id='direct_pay_button' onlcick='navigate_primary()'type='button'>Visa / Master / Amex</button></a>" +
                                        "</div>" +
                                        "<div class='col-sm-4'>" +
                                        "<a href='https://lotssolution.com/payment01/' target='_blank'><button class='btn btn-block btn-danger btn_02' id='razor_pay_button' onlcick='navigate_secondary()'type='button'>Secondary Payment</button></a>" +
                                        "</div>";
                                       // "<div class='col-sm-4'>"+
//                                        "<a href='https://lotssolution.com/payment02/' target='_blank'><button class='btn btn-block btn-danger btn_02' id='razor_pay_button' onlcick='navigate_secondary()'type='button'>CREDIT/ DEBIT</button></a>" +
                                       // "</div>";


                                $("#set_buttons").html(set_buttons);
                            }, 3500);
                        } else {
                            $("._dj_ltfx-error-block").show(500).find("span").html(res.msg);
                            setTimeout(function () {
                                $("._dj_ltfx-error-block").hide(500);
                                document.getElementById("nr_lotsfx_passcode_item").reset(); 
                                $("#id-authenticate-passcode").attr({disabled: false}).html("Submit Code");
                            }, 3500);
                        }
                    });
                }
            });


        });

    });
})(jQuery);
