<div class="row" id="set_buttons">
    <style>
        .bg_settings{
            background: #f9f9f9;
            padding: 25px;
            margin: 6% 0 0 0;
        }
        .titile_tag{
            text-align: center;
            color: #000;
        }
        .input_pass{
            padding: 9px 9px;
            font-size: 20px;
            text-align: center;
        }
        .btn_01{
            margin: 10px 0;
            border-radius: 0;
            padding: 13px;
            font-size: 18px;
        }
        .input-field.error{
            border: 1px solid red;
        }

        ._dj_ltfx-error-block{
            color: #fff;
            background-color: #d42121;
            border: 1px solid red;
            padding: 10px;
            /*border-radius: 10px;*/
        }
        ._dj_ltfx-error-block.success{
            color: #fff;
            background-color: #009900;
            border: 1px solid green;
            padding: 10px;
            /*border-radius: 10px;*/
        }
    </style>
    <div class="col-md-4"></div>
    <div class="col-md-4 col-sm-12 col-xs-12">
        <div class="bg_settings">
            <div class="col-sm-12">
                <p class="titile_tag">Enter Promo Code</p>
                <form  id="nr_lotsfx_passcode_item" method="POST" autocomplete="off">
                    <div class="row">
                        <div class="col-sm-12">
                            <input type="password" name="entry_code" id="entry_code" value="" class="form-control input_pass" >                      
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <button class="btn btn-block btn-warning btn_01"  id="id-authenticate-passcode">Submit Code</button>
                            <div class="_dj_ltfx-error-block" style="display: none;border-radius: 0px;">
                                <div class="row">
                                    <div class="col-sm-12 "><i class="icon-warning"></i> <span>Hello</span> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-4"></div>
</div>
<style>
    .btn_02{
        margin: 10% 0;
        padding: 5%;
        font-size: 18px;
    }

    .btn_02:hover{
        background: #000;
    }
</style>

