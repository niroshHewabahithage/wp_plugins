<?php
 session_start();
unset($_SESSION['is_looged']);
unset($_SESSION['user_name']);
?>
<script type="text/javascript">
    window.location.href = 'http://www.lotsfx.com/login';
</script>
