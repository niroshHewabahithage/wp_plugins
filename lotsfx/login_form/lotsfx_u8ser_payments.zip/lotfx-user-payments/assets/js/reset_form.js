jQuery.noConflict();
(function ($) {
    $(function () {
        $(document).ready(function () {
            $("#auth-button-reset_password").click(function () {


                var email = $("#reset-password-email").val();


                var b = false;
                if (email.trim() !== "" && typeof email !== "undefined") {
                    b = true;
                } else {
                    $("#reset-password-email").parent().addClass("error");
                    $("._dj_ltfx-error-block").show(500).find("span").html("Enter Email that you want to Varify");
                    setTimeout(function () {
                        $("._dj_ltfx-error-block").hide(500);
                        $("#reset-password-email").parent().removeClass("error");
                    }, 2500);
                }

                if (b) {

                    var data = $("#reset-form").serializeArray();
                    data.push({name: "action", value: "reset_form"});
                    console.log(data);
                    $("#auth-button-reset_password").attr({disabled: true}).html("Submitting...");

                    $.post(the_ajax_script.ajaxurl, data, function (response) {

                        $("#auth-button-reset_password").attr({disabled: false}).html("Submit");
                        var res = JSON.parse(response);

                        if (res.msg_type == "00") {
                            $("._dj_ltfx-error-block").addClass("success").show(500).find("span").html(res.msg);
                            setTimeout(function () {
                                window.location.href = res.url;
                            }, 1500);
                        } else {

                            $("._dj_ltfx-error-block").show(500).find("span").html(res.msg);
                            setTimeout(function () {
                                $("._dj_ltfx-error-block").hide(500);
                            }, 50000);
                        }
                    });
                }
                return false;
            });
        });
    });
})(jQuery);

