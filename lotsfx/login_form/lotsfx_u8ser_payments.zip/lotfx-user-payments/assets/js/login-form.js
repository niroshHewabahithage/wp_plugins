
jQuery.noConflict();
(function ($) {
    $(function () {
        $(document).ready(function () {
            $("#auth-button-login-btn").click(function () {

                var email = $("#login-input-name").val();
                var password = $("#login-input-password").val();


                var b = false;
                if (email !== "" && typeof email !== "undefined") {
                    if (password !== "" && typeof password !== "undefined") {
                        b = true;
                        $("#login-input-password").parent().removeClass("error");
                    } else {
                        $("#login-input-password").parent().addClass("error");
                    }
                    $("#login-input-name").parent().removeClass("error");
                } else {
                    $("#login-input-name").parent().addClass("error");
                }
                if (b) {
                    var data = $("#login-form").serializeArray();
                    data.push({name: "action", value: "login_user"});

                    $("#auth-button-login-btn").attr({disabled: true}).html("Logging...");

                    $.post(the_ajax_script.ajaxurl, data, function (response) {
                        $("#auth-button-login-btn").attr({disabled: false}).html("Login");
                        var res = JSON.parse(response);
                      
                        if (res.msg_type == "00") {
                            var user_name = res.user_name;
                            var user_email = res.user_email;
                            client_push("" + user_name + " Logged", user_email);
                            window.location.href = res.url;
                        } else {
                            $("._dj_ltfx-error-block").show(500).find("span").html(res.msg);
                            setTimeout(function () {
                                $("._dj_ltfx-error-block").hide(500);
                            }, 2500);
                        }
                    });
                }
                return false;
            });
        });
    });
})(jQuery);