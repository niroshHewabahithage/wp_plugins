jQuery.noConflict();
(function ($) {
    $(function () {
        $(document).ready(function () {
        
            alert();
        });
    });
})(jQuery);