//nirosh randimal
//sockets_io notifications
var socket = io("http://notfify2.cloudno.de:80");

socket.on("notify", function (data) {
    var logged_id = $("#log_id").val();
    var base = $("#base_url").val();

    if (data.reciver_ip == logged_id) {
        show_notification(data.text, "", "warning", 1000);
//        notficationDropDown
        var set_notification = "<tr class='profile'>" +
                "<td style='widows: 5%;padding:10px 0px 10px 10px;color: #ffd700;font-size: 22px;'><i class='fa fa-bell'></i></td>" +
                "<td style='widows:95%;padding:15px 0px 15px 10px;font-size:14px'>" + data.text + "</td>" +
                "</tr>";
        $("#notficationDropDown").append(set_notification);
        set_div_count();
    } else {
        //window.alert(data.reciver_ip);
    }
});
socket.on("login", function (data) {
    var log_type = $("#log_type").val();
    if (data.reciver_ip != log_type) {
        show_notification(data.text, "Hey..", "success", 1500);
    } else {

    }

});


function show_notification(txt_val, title, type, delay) {
    new PNotify({
        title: title,
        text: txt_val,
        type: type,
        delay: delay,
        animate: {
            animate: true,
            in_class: 'bounceInLeft',
            out_class: 'bounceOutRight'
        }

    });
}



function push_notification(text, reciver_ip) {
    var msg = {
        text: text,
        reciver_ip: reciver_ip,
    };
    socket.emit("notify", msg);
}
function push_notification_login(text, reciver_ip) {
    var msg = {
        text: text,
        reciver_ip: reciver_ip,
    };
    socket.emit("login", msg);
}
function client_push(text, username) {
    var msg = {
        text: text,
        username: username,
    };
    socket.emit("client", msg);
}




