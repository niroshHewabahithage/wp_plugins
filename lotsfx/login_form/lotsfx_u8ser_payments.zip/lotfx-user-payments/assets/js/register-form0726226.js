
jQuery.noConflict();
(function ($) {
    $(function () {
        $(document).ready(function () {
            $("#auth-button-create-account").click(function () {

                var name = $("#input-name").val();
                var email = $("#input-email").val();
                var number = $("#input-number").val();
                var country = $("#input-country").val();
                var password = $("#input-password").val();
                var c_password = $("#input-confirm-password").val();

                var b = false;
                if (name.trim() !== "" && typeof name !== "undefined") {

                    if (email !== "" && typeof email !== "undefined") {
                        if (number !== "" && typeof number !== "undefined") {
                            if (country !== "" && typeof country !== "undefined") {
                                b = true;
                                $("#input-country").parent().removeClass("error");
                            } else {
                                $("#input-country").parent().addClass("error");
                            }
                            $("#input-number").parent().removeClass("error");
                        } else {
                            $("#input-number").parent().addClass("error");
                        }
                        $("#input-email").parent().removeClass("error");
                    } else {
                        $("#input-email").parent().addClass("error");
                    }
                    $("#input-name").parent().removeClass("error");
                } else {
                    $("#input-name").parent().addClass("error");
                }

                if (b) {

                    var data = $("#register-form").serializeArray();
                    data.push({name: "action", value: "register_user"});
                   console.log(data);
                    $("#auth-button-create-account").attr({disabled: true}).html("CREATING...");

                    $.post(the_ajax_script.ajaxurl, data, function (response) {

                        $("#auth-button-create-account").attr({disabled: false}).html("Create Account");
                        var res = JSON.parse(response);

                        if (res.msg_type == "00") {
                            $("._dj_ltfx-error-block").addClass("success").show(500).find("span").html(res.msg);
                            setTimeout(function () {
//                                window.location.href = res.url;
                            }, 1500);
                        } else {

                            $("._dj_ltfx-error-block").show(500).find("span").html(res.msg);
                            setTimeout(function () {
                                $("._dj_ltfx-error-block").hide(500);
                            }, 50000);
                        }
                    });
                }
                return false;
            });
        });
    });
})(jQuery);

