/* global e */
jQuery.noConflict();
(function ($) {
    $(function () {
        $(document).ready(function () {
         
            var get_status_error = $("#status_error").val();
            if (get_status_error != "") {
                if (get_status_error == 1) {
                    $("._dj_ltfx-error-block").addClass("success").show(500).find("span").html("Successfully Uploaded ! ");
                    setTimeout(function () {
                        $("._dj_ltfx-error-block").hide(500);
                        window.location = "https://www.lotsfx.com/my-account/";
                    }, 3500);
                } else if (get_status_error == 0) {
                    $("._dj_ltfx-error-block").show(500).find("span").html("Something went wrong try again");
                    setTimeout(function () {
                        $("._dj_ltfx-error-block").hide(500);
                    }, 3500);
                }
            } else {
            }
            $("#auth-button-upload-btn").hide(500);
            var b = false;
            $("#upload_documents").change(function () {
                if (window.File && window.FileReader && window.FileList && window.Blob) {
                    //get the file size and file type from file input field
                    var fsize = $('#upload_documents')[0].files[0].size;
                    var ftype = $('#upload_documents')[0].files[0].type;
                    var fname = $('#upload_documents')[0].files[0].name;
                    if (fsize > (1048576 * 3)) //do something if file size more than 1 mb (1048576)
                    {
                        var str = "File size is too big! (max file size 3mb)";
                        $("._dj_ltfx-error-block").show(500).find("span").html(str);
                        $("#auth-button-upload-btn").hide(500);
                        setTimeout(function () {
                            $("._dj_ltfx-error-block").hide(500);
                        }, 2500);
                        $('#upload_documents')[0].files[0] = "";
                    } else {
                        switch (ftype) {
                            case 'application/pdf':
                            case 'application/msword':
                            case 'image/png':
                            case 'image/gif':
                            case 'image/jpeg':
                            case 'image/pjpeg':
                                var str = "";
                                $("#auth-button-upload-btn").show(500);
                                $("._dj_ltfx-error-block").hide(500);
                                break;
                            default:
                                var str = "Unsupported File!";
                                $("._dj_ltfx-error-block").show(500).find("span").html(str);
                                $("#auth-button-upload-btn").hide(500);
                                setTimeout(function () {
                                    $("._dj_ltfx-error-block").hide(500);
                                }, 2500);
                                $('#upload_documents')[0].files[0] = "";
                        }
                    }
                } else {
                    var str = "Please upgrade your browser, because your current browser lacks some new features we need!";
                    $("._dj_ltfx-error-block").show(500).find("span").html(str);
                    setTimeout(function () {
                        $("._dj_ltfx-error-block").hide(500);
                    }, 2500);
                }
            });
            $("#auth-button-upload-btn").click(function () {
                //alert($("#upload_documents").val());
                if ($("#upload_documents").val() != "") {
                    b = true;
                }
                if (b) {
                    // alert();
                    $("#my_details").submit();
                }
            });
            //  
            var x = false;
            var IDLE_TIMEOUT = 1800; //seconds
            var _idleSecondsCounter = 0;
            document.onclick = function () {
                _idleSecondsCounter = 0;
            };
            document.onmousemove = function () {
                _idleSecondsCounter = 0;
            };
            document.onkeypress = function () {
                _idleSecondsCounter = 0;
            };
            window.setInterval(CheckIdleTime, 1000);

            function CheckIdleTime() {
                if (x) {

                } else {
                    _idleSecondsCounter++;
                }
//                var oPanel = document.getElementById("SecondsUntilExpire");
//                if (oPanel)
//                    oPanel.innerHTML = (IDLE_TIMEOUT - _idleSecondsCounter) + "";
                if (_idleSecondsCounter >= IDLE_TIMEOUT) {
//                    $("#loginTimeout").modal('toggle');
                    var my_timeout = setTimeout(function () {
                        window.location = "https://www.lotsfx.com/navigate/";
                    }, 6500);
                    swal({
                        title: "Knok Knok",
                        text: "You Have Innactive in here more than 30 minutes. Is Anyone There, if not your system will logout automatically..",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    })
                            .then((willDelete) => {
                                if (willDelete) {
                                    window.location = "https://www.lotsfx.com/navigate/";
//clearTimeout(my_timeout)
                                } else {
                                    swal("Hi!", "Welcome Back to your Profile!", "success");
                                    x = false;
                                    clearTimeout(my_timeout);
                                }
                            });



//                    console.log("1");
                    x = true;
                    _idleSecondsCounter = 0;
//                    window.alert("timeout");

                    //document.location.href = "logout.html";
                }
            }
        });
    });
})(jQuery);