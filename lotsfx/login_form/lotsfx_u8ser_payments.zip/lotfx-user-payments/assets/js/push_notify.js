//push_notify
//nirosh randimal

$(document).ready(function () {
    $("#btn01").click(function () {
        var logged_id = $("#log_id").val();
 //window.alert();
 
        push_notification("New Leads has Been Assigned To You.. Check It Out", "27");
       
    });
    set_div_count();
    

});


/**
 * count_div_count
 */
function set_div_count() {
    $("#navbarDropdownMenuLink1 span").addClass("shake").html($('#notficationDropDown .profile').length);
    setTimeout(function () {
        $("#navbarDropdownMenuLink1 span").removeClass("shake");
    }, 1000);
}



