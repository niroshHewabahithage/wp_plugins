<?php
echo get_query_var('v');
$site_path = "https://www.lotsfx.com/wp-content/plugins/lotfx-user-payments/assets/js/";
?>
<div class="login-form">
    <div class="login-img"><img src="<?php echo site_url("wp-content/uploads/2018/07/login-img.png") ?>"></div>
    <h2>MEMBERS LOGIN</h2>
    <form action="#" id="login-form">
        <div class="name-field input-field">
            <i class="fas fa-user"></i> <input type="text" id="login-input-name" placeholder="E-mail" value="" name="email" />
        </div>
        <div class="email-field input-field">
            <i class="fas fa-envelope-open"></i> <input type="password" id="login-input-password" placeholder="Password" value="" name="password" />
        </div>

        <button class="btn btn-primary" id="auth-button-login-btn"> Login </button>
        <div class="auth-box-switch visible-xs"><span>Forget Your Password ?</span><a href=http://www.lotsfx.com/password-reset/" class="auth-login-link">Reset Now</a></div>
        <div class="auth-box-switch visible-xs"><span>Don't have an account ?</span><a href="<?php echo site_url("register") ?>" class="auth-login-link">Sign Up</a></div>
        <div class="container-fluid _dj_ltfx-error-block" style="display: none;">
            <div class="row">
                <div class="col-sm-12 error-message"><i class="icon-warning"></i> Email or password incorrect, Please try again. </div>
            </div>
        </div>
    </form>
</div>
<script src="<?php echo $site_path;?>socket.io.slim.js"></script>
<script src="<?php echo $site_path;?>socket.io-client.min.js"></script>
<script src="<?php echo $site_path;?>notification.js"></script>


