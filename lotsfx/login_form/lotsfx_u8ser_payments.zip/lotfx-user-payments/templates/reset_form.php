<div class="reset-form">
    <form action="#" id="reset-form">
        <h2>RESET YOUR PASSWORD NOW</h2>
        <div class="name-field input-field"><i class="fas fa-envelope-open"></i> <input type="email" id="reset-password-email" placeholder="Email" value="" name="email"></div>
        <button class="btn btn-primary" id="auth-button-reset_password">Submit</button>
        <div class="container-fluid  _dj_ltfx-error-block" style="display: none;">
            <div class="row">
                <div class="col-sm-12 error-message"><i class="icon-warning"></i><span></span> </div>
            </div>
        </div>
    </form>
</div>