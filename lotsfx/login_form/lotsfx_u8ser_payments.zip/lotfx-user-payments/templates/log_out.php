<?php
$site_url = 'https://www.lotsfx.com/';
session_start();
$id_user = $_SESSION['id_user'];
unset($_SESSION['is_looged']);
unset($_SESSION['user_name']);

if ($_SESSION['is_looged'] == "" && $_SESSION['user_name'] == "") {
    global $wpdb;
    global $table_name;
    $row = $wpdb->get_row("UPDATE wp_ltfx_users SET status = '0' WHERE (id = '$id_user');");
    ?>
    <script>
        window.location.href = '<?php echo $site_url; ?>login/';
    </script>
    <?php
} else {
   ?>
    <script>
        window.location.href = '<?php echo $site_url; ?>my-account/';
    </script>
    <?php 
}
?>