<link href="https://www.lotsfx.com/wp-content/plugins/lotfx-user-payments/assets/css/dataTables.bootstrap.min.css">
<!--<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">-->
<!--<script src="https://code.jquery.com/jquery-3.3.1.js"></script>-->
<script src="https://www.lotsfx.com/wp-content/plugins/lotfx-user-payments/assets/js/jquery.dataTables.min.js"></script>
<!--<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>-->
<div class="container">
    <style>
        th{
            padding: 15px;
            text-align: left;
            font-size: 18px;
            color: #fff;
            background: #36a5da;
        }
        td{
            background: #d8d7d7;
            padding: 15px 5px;
            font-size: 15px;
            /* color: #000; */
            font-weight: 500;
        }
      
    </style>
    <div class="row" style="padding:0% 8% 0% 8% ;">
        <h3>Registered Users</h3>
        <table id="example" class="table table-striped table-bordered" style="width:100%;background: #fff;">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email Address</th>
                    <th>Contact Number</th>
                    <th>Country</th>
                    <th>Created Date</th>



                </tr>
            </thead>
            <tbody>
                <?php
                global $wpdb;
                global $table_name;

                $row = $wpdb->get_results("SELECT * FROM wp_ltfx_users ");

                if (!empty($row)) {
                    foreach ($row as $value) {
                        ?>

                        <tr>
                            <td><?php echo $value->name; ?></td>
                            <td><?php echo $value->email; ?></td>
                            <td><?php echo $value->code_country; ?><?php echo $value->phone; ?></td>
                            <td><?php echo $value->country; ?></td>
                            <td><?php echo $value->created_on; ?></td>


                        </tr>


                        <?php
                    }
                } else {
                    ?>

                    <tr>
                        <td colspan="5" style="text-align: center;letter-spacing: 5px">No Results Found</td>


                    </tr>


                    <?php
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Name</th>
                    <th>Position</th>
                    <th>Office</th>
                    <th>Age</th>
                    <th>Created Date</th>


                </tr>
            </tfoot>
        </table>
    </div>

</div>
<script>
    jQuery.noConflict();
    (function ($) {
        $(function () {

            $(document).ready(function () {
                $('#example').DataTable();
            });
        });
    })(jQuery);
</script>
