<!--<script src="./myalert.js"></script>-->
<?php
$site_url = 'https://www.lotsfx.com/';
$updated_text = "";
if (isset($_GET['status'])) {
    $updated_text = "2";
    if ($_GET['status'] == 'success') {
        global $wpdb;
        $table_name2 = "wp_upload_user";
        $data = array(
            "id_user" => $_SESSION['id_user'],
            "is_uploaded" => "1",
        );
        $wpdb->insert($table_name2, $data);
        $updated_text = "1";
    } else if ($_GET['status'] == 'fail') {

        $updated_text = "0";
    }
} else {
//   $updated_text = "3"; 
}
//echo $_SESSION['is_looged'];
//echo $_SESSION['id_user'];
if ($_SESSION['is_looged']) {
//    $_SESSION['is_looged'] = TRUE; 
//                $_SESSION['id_user'] = $user_id; 
//                $_SESSION['user_name'] = $user_name; 

    global $wpdb;
    global $table_name;
    $table_name2 = "wp_upload_user";
    $row = $wpdb->get_row("SELECT * FROM $table_name WHERE id= " . $_SESSION['id_user'] . "");
    $id_user = $row->id;
    $name = $row->name;
    $email = $row->email;
    $telephone = $row->code_country . $row->phone;
    $country = $row->country;
    $created_date = $row->created_on;
    $row2 = $wpdb->get_row("SELECT * FROM $table_name2 WHERE id_user= " . $_SESSION['id_user'] . " order by id desc limit 1");
    $not_empty = FALSE;
    if ($row2) {
        $not_empty = TRUE;
    }
    ?>


    <?php
} else {
    ?>
    <script type="text/javascript">
        window.location.href = '<?php echo $site_url; ?>login/';
    </script>
<?php }
?>
<div class="container">
    <div class="row">
        <table style="width: 100%">
            <tbody>
                <tr>
                    <td style="width: 2%"><p style='font-size:18px'></p></td>
                    <td style="width: 15%"><p style='font-size:18px'>Names</p></td>
                    <td style="width: 2%"><p style='font-size:18px'>-</p></td>
                    <td style="width: 81%"><p style='font-size:18px'><?php echo $name; ?></p></td>
                </tr>
                <tr>
                    <td style="width: 2%"><p style='font-size:18px'></p></td>
                    <td style="width: 15%"><p style='font-size:18px'>Email Address</p></td>
                    <td style="width: 2%"><p style='font-size:18px'>-</p></td>
                    <td style="width: 81%"><p style='font-size:18px'><?php echo $email; ?></p></td>
                </tr>
                <tr>
                    <td style="width: 2%"><p style='font-size:18px'></p></td>
                    <td style="width: 15%"><p style='font-size:18px'>Phone Number</p></td>
                    <td style="width: 2%"><p style='font-size:18px'>-</p></td>
                    <td style="width: 81%"><p style='font-size:18px'><?php echo $telephone; ?></p></td>
                </tr>
                <tr>
                    <td style="width: 2%"><p style='font-size:18px'></p></td>
                    <td style="width: 15%"><p style='font-size:18px'>Country</p></td>
                    <td style="width: 2%"><p style='font-size:18px'>-</p></td>
                    <td style="width: 81%"><p style='font-size:18px'><?php echo $country; ?></p></td>
                </tr>
                <tr>
                    <td style="width: 2%"><p style='font-size:18px'></p></td>
                    <td style="width: 15%"><p style='font-size:18px'>Registered Date</p></td>
                    <td style="width: 2%"><p style='font-size:18px'>-</p></td>
                    <td style="width: 81%"><p style='font-size:18px'><?php echo $created_date; ?></p></td>
                </tr>
                <?php if ($not_empty) {
                    ?>
                    <tr>
                        <td style="width: 2%"><p style='font-size:18px'></p></td>
                        <td style="width: 15%"><p style='font-size:18px'>Update Status</p></td>
                        <td style="width: 2%"><p style='font-size:18px'>-</p></td>
                        <td style="width: 81%"><p style='font-size:18px'>Updated</p></td>
                    </tr>
                    <?php
                } else {
                    ?>
                    <tr>
                        <td style="width: 2%"><p style='font-size:18px'></p></td>
                        <td style="width: 15%"><p style='font-size:18px'>Update Status</p></td>
                        <td style="width: 2%"><p style='font-size:18px'>-</p></td>
                        <td style="width: 81%"><p style='font-size:18px'>No any Uploads</p></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
        <table>
            <tbody>
            <form action="https://lotsfx.com/wp-content/plugins/lotfx-user-payments/upload.php?fn=upload" id="my_details" enctype="multipart/form-data" method="post">
                <tr>
                    <td colspan="3" ><input type="file" class="btn btn-primary btn-block" name="upload_docs" id="upload_documents" style="padding: 17px;border: none;border-radius: 0px;background: #711615;">
                    </td>
                    <td colspan="1" >
                        <input type='hidden' id='status_error' value='<?php echo $updated_text; ?>'>
                        <input type="hidden" name="id_user" id="input_id" value="<?php echo $id_user; ?>">
                        <input type="hidden" name="name_user" id="name_user" value="<?php echo $name; ?>">
                        <input type="hidden" name="email_user" id="email_user" value="<?php echo $email; ?>">
                        <input type="hidden" name="phone_user" id="phone_user" value="<?php echo $telephone; ?>">
                        <button class="btn btn-primary " id="auth-button-upload-btn"  style="padding: 20px;border: none;border-radius: 0px;background: #711615;"> Upload Documents </button>
                    </td>
                </tr>
                <tr>
                    <td  style="width: 100%"><div class="container-fluid _dj_ltfx-error-block" style="display: none;">
                            <div class="row">
                                <div class="col-sm-12 "><center><i class="icon-warning"></i><span></span> </center></div>
                            </div>
                        </div></td>
                </tr>
            </form>
            </tbody>
        </table>
    </div>
</div>
