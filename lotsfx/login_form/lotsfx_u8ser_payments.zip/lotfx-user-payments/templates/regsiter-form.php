<!--<script src="http://www.geoplugin.net/javascript.gp" type="text/javascript"></script>-->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<div class="register-form">

    <form action="#" id="register-form">
        <h2>CREATE YOUR ACCOUNT</h2>
        <div class="name-field input-field"><i class="fas fa-user"></i> <input type="text" id="input-name" placeholder="Name" value="" name="name" ></div>
        <div class="email-field input-field"><i class="fas fa-envelope-open"></i> <input type="email" id="input-email" placeholder="Email" value="" name="email" ></div>
        <div class="country-field input-field"><i class="fas fa-user"></i> <input type="text" id="input-country" placeholder="Country" value="" name="country"></div>
        <div class="phone-field-number input-field"><i class="fas fa-mobile-alt"></i>   <select name="country-code" id="country-code">
<!--                <option value="srilanka">+94</option>-->
            </select> <input type="number" id="input-number" placeholder="Phone Number" value="" name="number"></div>

        <button class="btn btn-primary" id="auth-button-create-account"> Create Account </button>
        <div class="auth-box-switch visible-xs"><span>Already have an account?</span><a href="https://www.lotsfx.com/login/" class="auth-login-link">Login</a></div>
        <div class="container-fluid _dj_ltfx-error-block" style="display: none;">
            <div class="row">
                <div class="col-sm-12 "><i class="icon-warning"></i> <span></span> </div>
            </div>
        </div>
    </form>
</div>

<script>
    jQuery.noConflict();
    (function ($) {
        $(function () {
            $(document).ready(function () {
                loadCurrent();
//                loadCountries();
            });
            function loadCurrent() {
//                jQuery.getScript('http://www.geoplugin.net/javascript.gp', function ()
//                {
//                    var country = geoplugin_countryName();
//
//                    var code = geoplugin_countryCode();
//                    console.log(code);
//                    loadCountries(code);
//                });
////                $.getJSON('https://json.geoiplookup.io/api?callback=', function (data) {
////                    console.log(JSON.stringify(data, null, 2));
////                });
//                $.getJSON("https://api.ipify.org?format=jsonp&callback=?",
//                        function (json) {
//                            console.log("My public IP address is: ", json.ip);
//                        }
//                );
                $.get("https://api.ipdata.co?api-key=0967bbe2085a93d5b2413cc11bffec21c6c9f024f65558412699307c", function (response) {
//                    console.log('Country Name: ' + response.country_name);
//                    console.log('Country Code: ' + response.country_code);
//                    console.log('City: ' + response.city);
//                    console.log('region: ' + response.region);
                    var country_code = response.country_code;
                    console.warn(country_code);
                    loadCountries(country_code);
                }, "jsonp");

            }
            function loadCountries(codeCountry) {
                $.getJSON("../wp-content/plugins/lotfx-user-payments/assets/countries.json", function (data) {
                    const arrayitem = JSON.parse(JSON.stringify(data));
                    console.log(arrayitem);
                    arrayitem.sort();

                    var set_options = "";
                    var new_value = "";
                    if (arrayitem.length > 0) {
                        for (var i = 0; i < arrayitem.length; i++) {
                            const countryDialCode = arrayitem[i].dial_code;
                            const countrylCode = arrayitem[i].code;
                            const countryName = arrayitem[i].name;
                            if (codeCountry == countrylCode) {
                                new_value = countryDialCode;
                                console.log(new_value);
                            }

                            set_options += "<option  value='" + countryDialCode + "'>" + countryDialCode + "</option>";
                        }
                        if (new_value != "") {
                            set_options += "<option selected='selected' value='" + new_value + "'>" + new_value + "</option>";
                        }
//                        set_options += "<option selected='selected' value='+94'>+94</option>";
                        set_options += "</select>";
                        $("#country-code").html(set_options);
                    }
//                    
                });
            }


        });
    })(jQuery);

</script>
