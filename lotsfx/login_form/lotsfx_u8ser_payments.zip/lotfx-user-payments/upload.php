<?php

//
//Jul 31, 2018 10:55:30 AM 
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require 'phpmailer/class.phpmailer.php';
require 'phpmailer/class.smtp.php';
if (isset($_GET['fn'])) {
    if ($_GET['fn'] == 'upload') {
        _dj_ltfx_my_details();
    }
}

function _dj_ltfx_my_details() {
    $t = time();
    if (isset($_FILES['upload_docs'])) {
        $IS_validation = FALSE;
        $user_id = "";
        $name = "";
        $email = "";
        $telephone = "";


        if (isset($_POST['id_user']) && isset($_POST['name_user']) && isset($_POST['email_user'])) {
            $user_id = $_POST['id_user'];
            $name = $_POST['name_user'];
            $email = $_POST['email_user'];
            $telephone = $_POST['phone_user'];

            $IS_validation = TRUE;
        }

        if ($IS_validation) {
            $errors = array();
            $file_name = $_FILES['upload_docs']['name'];
            $file_size = $_FILES['upload_docs']['size'];
            $file_tmp = $_FILES['upload_docs']['tmp_name'];
            $file_type = $_FILES['upload_docs']['type'];
            $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));

            $file_name1 = "_ltfx" . $t . $file_name . "";
            if ($file_size > 3097152) {
                $errors[] = 'File size must be excately 2 MB';
            }

            if (empty($errors) == true) {
                move_uploaded_file($file_tmp, "uploads/" . $file_name1);
//                echo "Success";
//                echo '<br>';
//                echo ""
//                . "";

                $mail = new PHPMailer();
                $mail->isSMTP();

                $mail->Host = "secure232.servconfig.com";  // specify main and backup server
                $mail->Port = 587;
                $mail->SMTPSecure = 'tls';


                $mail->SMTPAuth = true;     // turn on SMTP authentication
                $mail->Username = "noreply@lotsfx.com";  // SMTP username
                $mail->Password = 'Q,+W~K%WPPtU'; // SMTP password

                $mail->From = "noreply@lotsfx.com";
                $mail->setFrom('noreply@lotsfx.com', 'Lotsfx');


                $mail->AddAddress("register@lotsfx.com", "Admin");


                $mail->IsHTML(true);                                  // set email format to HTML
                $mail->Subject = "Attchement Recieved";
                $mail->Body = "<div style='width: 500px; margin: 0 auto; border: 1px solid #dadada; box-shadow: 0px 0px 5px 0px #ececec;'>"
                        . "<div style='text-align: center;'>"
                        . "<a href='https://www.lotsfx.com/'>"
                        . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/07/logo.png'>"
                        . "</a></div>"
                        . "<div style='text-align: center; padding: 27px 5px 8px; margin: 30px 1px; color: #d4d4d4; background: linear-gradient(to bottom right, #313131, #173058); font-family: monospace;'>"
                        . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/08/check.png'>"
                        . "<h2>New Attachment</h2>"
                        . "</div><div style='padding: 0px 30px;'>"
                        . "<h3>$name Has Sent You a File Attachment press below button</h3>"
                        . "<table style='width: 100%;'>"
                        . "<tr>"
                        . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>Phone number</td>"
                        . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>$telephone</td>"
                        . "</tr>"
                        . "<tr>"
                        . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>Email</td>"
                        . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>$email</td>"
                        . "</tr>"
                        . "</table>"
                        . "<hr>"
                        . "</div>"
                        . "<div style='text-align: center;'>"
                        . "<a href='https://lotsfx.com/wp-content/plugins/lotfx-user-payments/uploads/$file_name1' download style='background-color: #d62f32; padding: 10px; border-radius: 4px; display: inline-block; margin: 15px 0px; text-decoration: none; font-size: 15px; font-family: Tahoma; color: white;'>View Attachment</a>"
                        . "</div>"
                        . "<div>"
                        . "<p style='text-align: center; font-family: Tahoma; font-size: 13px; line-height: 21px; padding: 0px 15px 10px;'>If you are having any issues with your account, please don't hesitate to contact us by replying to this mail. Thanks!</p><p style='    text-align: center; font-family: Tahoma; font-size: 11px; line-height: 21px; padding: 4px 15px 8px; background-color: #efefef; margin-bottom: 0;'>You're receiving this email because you have an account in Hun, If you are not sure why you're receiving this, please contact us.</p>"
                        . "</div>"
                        . "</div>";



                if (!$mail->send()) {
//                    $json["msg"] = 'Message could not be sent.';
//                    $json["msg"] = 'error' . $mail->ErrorInfo;

                    header("Location: https://www.lotsfx.com/my-account?status=fail");
                } else {
//                    $json["msg"] = 'Message has been sent';
//                    header("Location: 'https://www.lotsfx.com/my-account?status=success");
                    header("Location: https://www.lotsfx.com/my-account?status=success");
                  
                }
            } else {
                header("Location: https://www.lotsfx.com/my-account?status=fail");
            }
        } else {
            header("Location: https://www.lotsfx.com/my-account?status=fail");
        }
    } else {
        header("Location: https://www.lotsfx.com/my-account?status=fail");
    }
}

?>