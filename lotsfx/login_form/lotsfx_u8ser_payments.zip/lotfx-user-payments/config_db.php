<?php
$base_url = "https://www.lotsfx.com/";
//$login_url = "http://www.lotsfx.com/login/";

defined($base_url);
//defined($login_url);

?>