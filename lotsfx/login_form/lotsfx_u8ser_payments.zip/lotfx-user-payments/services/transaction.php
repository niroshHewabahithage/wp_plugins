<?php

require_once("./config/config_path.php");
('Cache-Control: no-cache, must-revalidate');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// get & validate access token with the databse
//$token = null;
//$headers = apache_request_headers();
////$token = $headers['Authorization'];

$finalResponse = null;


$resObj = new stdClass();
//check for POST method type
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $request = file_get_contents('php://input');
    $input = json_decode($request);
    $json_a = json_decode($request, true);


    //DB call for customer validation
    require_once("./config/config_db.php");
    try {
        if ($conn != null) {
            $conn->query('set character_set_client=utf8');
            $conn->query('set character_set_connection=utf8');
            $conn->query('set character_set_results=utf8');
            $conn->query('set character_set_server=utf8');

            //


            $sql = "SELECT * FROM wp_ltfx_users where email NOT like '%" . $ignore_text . "%';";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                //  found              
                $rootsAr = [];
                while ($row = $result->fetch_assoc()) {
                    $singleRoot = new stdClass();
                    $singleRoot->lead_name = $row["name"];
                    $singleRoot->email = $row["email"];
                    $singleRoot->phone = $row["phone"];
                    $singleRoot->status = $row["status"];
                    $singleRoot->timeStamp = $row["timestamp"];
                    array_push($rootsAr, $singleRoot);
                }

                $resObj->rootsArray = $rootsAr;
                $resObj->error_code = "200";
                $resObj->error = "SUCCESS";
                $resObj->error_description = "Valid Request";
                http_response_code(200);
            } else {
                // no found
                $resObj->error_code = "200";
                $resObj->error = "NODATA";
                $resObj->error_description = "Valid Request But No Data Found";
                http_response_code(200);
            }
        } else {
            // no databse connection
            // Error
            $resObj->error_code = "500";
            $resObj->error = "INTERNAL_ERROR";
            $resObj->error_description = "Cannot connect with database. Please try later.";
            http_response_code(500);
        }
    } catch (Exception $e) {
        // Error
        $resObj->error_code = "500";
        $resObj->error = "INTERNAL_ERROR";
        $resObj->error_description = "Cannot connect with database. Please try later.";
        http_response_code(500);
//        } finally {
//            // close connection
//            if ($conn != null) {
//                try {
//                    $conn->close();
//                } catch (Exception $ex) {
//                    // gnore
//                }
//            }
//        }
    }
} else {
    $resObj->error_code = "400";
    $resObj->error = "BAD_REQUEST";
    $resObj->error_description = "Invalid request type: Request must be POST";
    http_response_code(400);
}

$finalResponse = $resObj;
echo json_encode($finalResponse, JSON_UNESCAPED_UNICODE);
?>