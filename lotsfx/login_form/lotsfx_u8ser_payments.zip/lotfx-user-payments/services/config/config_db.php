<?php

$servername = "172.104.185.97:3306";
$username = "lotsfx";
$password = "l3Pe5QN4EuNbu2zy";
$dbname = "lotsfx";



$conn = null;
error_reporting(1);
try {
// Create connection

    $conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
    if ($conn->connect_error) {
        $conn = null;
        // die("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    //echo 'Caught exception: ', $e->getMessage(), "\n";
}

