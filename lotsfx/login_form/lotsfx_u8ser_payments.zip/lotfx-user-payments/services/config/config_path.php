<?php

//$working_host = "http://192.168.8.102/eguide_service/eguide_service/";
$working_host = "http://eguide.lk/eguide_service/";
$ignore_text = "lotsfx.com";

