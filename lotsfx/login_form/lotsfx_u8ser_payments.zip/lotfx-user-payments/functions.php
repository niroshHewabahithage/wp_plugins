<?php
/*
  Plugin Name: Users Management
  Plugin URI: http://weblankan.com
  Description: User and Payment Management Plugin
  Version: 1.0
  Author: Nirosh Randimal
  Author URI: www.linkedin.com/in/nirosh-randimal-331598146
  License: GPL2
 */

if (isset($_GET['b'])) {
    
}

global $me_db_version;
global $folder;
global $site_url;
global $uri_segnemt;
global $limit;
global $table_name;
global $ltfx_db_version;
//require_once "src/Mail.php";
require 'phpmailer/class.phpmailer.php';
require 'phpmailer/class.smtp.php';
//include "phpmailer/PHPMailer.php";
$ltfx_db_version = '1.0.0';
//$folder = 'sliit-sms';
$folder = 'lotsfx';
$uri_segnemt = 5;
$limit = 5;
global $wpdb;
$table_name = $wpdb->prefix . "ltfx_users";
$admin_email = 'info@lotsfx.com';
//$_SESSION['is_looged'] == "";
session_start();
//$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
//$domainName = $_SERVER['HTTP_HOST'] . '/';
//$site_url = $protocol . $domainName;
$site_url = "https://lotsfx.com/";
$site_login = "https://lotsfx.com/";

//$host = '127.0.0.1';
//$db = 'sliit_sms';
//$user = 'root';
//$pass = '';
//
//$host = 'localhost';
//$db = 'lotsfx';
//$user = 'root';
//$pass = '';
//
//
//$dsn = "mysql:host=$host;dbname=$db;";
//$opt = [
//    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
//    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
//    PDO::ATTR_EMULATE_PREPARES => false,
//];
//global $pdo;
//$pdo = new PDO($dsn, $user, $pass, $opt);

function _dj_sliit_sf_install() {

    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    global $table_name;
    global $ltfx_db_version;
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
                    `id`  int(11) NOT NULL AUTO_INCREMENT ,
                `name`  varchar(255) NOT NULL ,
                `email`  varchar(255) NOT NULL ,
                `code_country`  varchar(20) ,
                `phone`  varchar(255) NULL ,
                `country`  varchar(255) NULL ,
                `password`  varchar(255) NOT NULL ,
                `created_on`  datetime NOT NULL ,
                `status`  int(2) ZEROFILL NOT NULL ,
                `other`  text NULL ,
                PRIMARY KEY (`id`)
	) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta($sql);

    add_option('ltfx_db_version', $ltfx_db_version);
}

register_activation_hook(__FILE__, '_dj_sliit_sf_install');
register_activation_hook(__FILE__, '_dj_sliit_sf_my_activation_func');

# log activating Errors

function _dj_sliit_sf_my_activation_func() {
    file_put_contents(__DIR__ . '/my_loggg.txt', ob_get_contents());
}

function _dj_ltfx_load_regster_form() {
    wp_enqueue_style('_dj_ltfx-main', plugins_url('assets/css/main.css', __FILE__));
    wp_enqueue_script('_dj_ltfx-register-form', plugins_url("assets/js/register-form.js", __FILE__), array('jquery'), 1.1, true);

    // make the ajaxurl var available to the above script
    wp_localize_script('_dj_ltfx-register-form', 'the_ajax_script', array('ajaxurl' => admin_url('admin-ajax.php')));

//    include __DIR__ . './inc/ipfinder.php';
//    $country_code = ip_info(null, "Country Code");
    ob_start();
//    $code = get_code($country_code);
    include (__DIR__ . "/templates/regsiter-form.php");
    return ob_get_clean();
}

function _dj_ltfx_load_login_form() {


    if ($_SESSION['is_looged'] != "") {
        ?>
        <script type="text/javascript">
            window.location.href = '<?php echo $site_url; ?>my-account/';
        </script>

        <?php
    } else {
        wp_enqueue_style('_dj_ltfx-main', plugins_url('assets/css/main.css', __FILE__));
        wp_enqueue_script('_dj_ltfx-login-form.js', plugins_url("assets/js/login-form.js", __FILE__), array('jquery'), 1.1, true);

// make the ajaxurl var available to the above script
        wp_localize_script('_dj_ltfx-login-form.js', 'the_ajax_script', array('ajaxurl' => admin_url('admin-ajax.php')));


        ob_start();
        include (__DIR__ . "/templates/login-form.php");
        return ob_get_clean();
    }
}

function _dj_ltfx_load_reset_form() {
    wp_enqueue_style('_dj_ltfx-main', plugins_url('assets/css/main.css', __FILE__));
    wp_enqueue_script('_dj_ltfx-reset_form', plugins_url("assets/js/reset_form.js", __FILE__), array('jquery'), 1.1, true);

// make the ajaxurl var available to the above script
    wp_localize_script('_dj_ltfx-reset_form', 'the_ajax_script', array('ajaxurl' => admin_url('admin-ajax.php')));


    ob_start();
    include (__DIR__ . "/templates/reset_form.php");
    return ob_get_clean();
}

function _dj_ltfx_load_my_details() {
//    session_start();
//unset($_SESSION['is_looged']);
//unset($_SESSION['user_name']);
    wp_enqueue_style('_dj_ltfx-main', plugins_url('assets/css/main.css', __FILE__));
    wp_enqueue_script('_dj_ltfx-my_details', plugins_url("assets/js/my_details.js", __FILE__), array('jquery'), 1.1, true);
    wp_enqueue_script('_dj_ltfx-my_details_alert', plugins_url("assets/js/myalert.js", __FILE__), array('jquery'), 1.1, true);

// make the ajaxurl var available to the above script
    wp_localize_script('_dj_ltfx-my_details', 'the_ajax_script', array('ajaxurl' => admin_url('admin-ajax.php')));
    wp_localize_script('_dj_ltfx-my_details_alert', 'the_ajax_script', array('ajaxurl' => admin_url('admin-ajax.php')));


    ob_start();
    include (__DIR__ . "/templates/my_detials.php");
    return ob_get_clean();
}

function _dj_ltfx_load_log_out() {
//    session_start();
//unset($_SESSION['is_looged']);
//unset($_SESSION['user_name']);
    wp_enqueue_style('_dj_ltfx-main', plugins_url('assets/css/main.css', __FILE__));
    wp_enqueue_script('_dj_ltfx-log_out_js', plugins_url("assets/js/log_out.js", __FILE__), array('jquery'), 1.1, true);

// make the ajaxurl var available to the above script
    wp_localize_script('_dj_ltfx-log_out_js', 'the_ajax_script', array('ajaxurl' => admin_url('admin-ajax.php')));


    ob_start();
    include (__DIR__ . "/templates/log_out.php");
    return ob_get_clean();
}

add_shortcode('register-form', '_dj_ltfx_load_regster_form');
add_shortcode('login-form', '_dj_ltfx_load_login_form');
add_shortcode('reset_page', '_dj_ltfx_load_reset_form');
add_shortcode('my_details', '_dj_ltfx_load_my_details');
add_shortcode('logout_page', '_dj_ltfx_load_log_out');

add_action('wp_ajax_nopriv_register_user', '_dj_ltfx_register_user');
add_action('wp_ajax_nopriv_login_user', '_dj_ltfx_login_user');
add_action('wp_ajax_nopriv_reset_form', '_dj_ltfx_reset_form');
add_action('wp_ajax_nopriv_logout_page12', '_dj_ltfx_logout_page123');

function _dj_ltfx_logout_page123() {
    print_r($_POST);
}

function _dj_ltfx_reset_form() {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    $json = array();
    $email = $_POST['email'];
    $dec = strtok($email, '@');
    if (!empty($email)) {
        if (is_email($email)) {
            global $wpdb;
            global $table_name;
            $row = $wpdb->get_row("SELECT * FROM $table_name WHERE email='$email'");

            if (!empty($row)) {
                $name = $row->name;
                $password = wp_generate_password(8, FALSE);
                $encrypted_pass = md5($password);
                $row2 = $wpdb->get_row("UPDATE $table_name SET password='$encrypted_pass',other='$password' WHERE email='$email'");
                $json["msg_type"] = "00";
                $json["url"] = site_url("login");
                $mail = new PHPMailer();
                $mail->isSMTP();

                $mail->Host = "secure232.servconfig.com";  // specify main and backup server
                $mail->Port = 587;
                $mail->SMTPSecure = 'tls';


                $mail->SMTPAuth = true;     // turn on SMTP authentication
                $mail->Username = "password@lotsfx.com";  // SMTP username
                $mail->Password = '2u=D_c#]WP3j'; // SMTP password

                $mail->From = "password@lotsfx.com";
                $mail->setFrom('password@lotsfx.com', 'Lotsfx');


                $mail->AddAddress("$email", "$name");


                $mail->IsHTML(true);                                  // set email format to HTML
                $mail->Subject = "LOTSFX PASSWORD REQUEST";
                $mail->Body = "<div style='width: 500px; margin: 0 auto; border: 1px solid #dadada; box-shadow: 0px 0px 5px 0px #ececec;'>"
                        . "<div style='text-align: center;'>"
                        . "<a href='https://www.lotsfx.com/'>"
                        . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/07/logo.png'>"
                        . "</a></div>"
                        . "<div style='text-align: center; padding: 27px 5px 8px; margin: 30px 1px; color: #d4d4d4; background: linear-gradient(to bottom right, #313131, #173058); font-family: monospace;'>"
                        . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/08/check.png'>"
                        . "<h2>LOTSFX PASSWORD</h2>"
                        . "</div><div style='padding: 0px 30px;'>"
                        . "<h3>Your New Logins</h3>"
                        . "<table style='width: 100%;'>"
                        . "<tr>"
                        . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>User Name</td>"
                        . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>$email</td>"
                        . "</tr>"
                        . "<tr>"
                        . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>New Password</td>"
                        . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>$password</td>"
                        . "</tr>"
                        . "</table>"
                        . "<hr>"
                        . "</div>"
                        . "<div style='text-align: center;'>"
                        . "<a href='https://www.lotsfx.com/login/' style='background-color: #d62f32; padding: 10px; border-radius: 4px; display: inline-block; margin: 15px 0px; text-decoration: none; font-size: 15px; font-family: Tahoma; color: white;'>LOGIN TO YOUR ACCOUNT</a>"
                        . "</div>"
                        . "<div>"
                        . "<p style='text-align: center; font-family: Tahoma; font-size: 13px; line-height: 21px; padding: 0px 15px 10px;'>If you are having any issues with your account, please don't hesitate to contact us by replying to this mail. Thanks!</p><p style='    text-align: center; font-family: Tahoma; font-size: 11px; line-height: 21px; padding: 4px 15px 8px; background-color: #efefef; margin-bottom: 0;'>You're receiving this email because you have an account in LOTSFX, If you are not sure why you're receiving this, please contact us.</p>"
                        . "</div>"
                        . "</div>";



                if (!$mail->send()) {
//                    $json["msg"] = 'Message could not be sent.';
//                    $json["msg"] = 'error' . $mail->ErrorInfo;
                } else {
//                    $json["msg"] = 'Message has been sent';
                }

                $mail = new PHPMailer();
                $mail->isSMTP();

                $mail->Host = "secure232.servconfig.com";  // specify main and backup server
                $mail->Port = 587;
                $mail->SMTPSecure = 'tls';


                $mail->SMTPAuth = true;     // turn on SMTP authentication
                $mail->Username = "password@lotsfx.com";  // SMTP username
                $mail->Password = '2u=D_c#]WP3j'; // SMTP password

                $mail->From = "password@lotsfx.com";
                $mail->setFrom('password@lotsfx.com', 'Lotsfx');


                // $mail->AddAddress("info@lotsfx.com", "Josh Adams");
                $mail->AddAddress("register@lotsfx.com", "Josh Adams");


                $mail->IsHTML(true);                                  // set email format to HTML
                $mail->Subject = "LOTSFX PASSWORD REQUEST";
                $mail->Body = "<div style='width: 500px; margin: 0 auto; border: 1px solid #dadada; box-shadow: 0px 0px 5px 0px #ececec;'>"
                        . "<div style='text-align: center;'>"
                        . "<a href='https://www.lotsfx.com/'>"
                        . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/07/logo.png'>"
                        . "</a></div>"
                        . "<div style='text-align: center; padding: 27px 5px 8px; margin: 30px 1px; color: #d4d4d4; background: linear-gradient(to bottom right, #313131, #173058); font-family: monospace;'>"
                        . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/08/check.png'>"
                        . "<h2>LOTSFX PASSWORD</h2>"
                        . "</div><div style='padding: 0px 30px;'>"
                        . "<h3>$name has requested new password for the system, these are $name's new logins</h3>"
                        . "<table style='width: 100%;'>"
                        . "<tr>"
                        . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>User Name</td>"
                        . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>$email</td>"
                        . "</tr>"
                        . "<tr>"
                        . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>New Password</td>"
                        . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>$password</td>"
                        . "</tr>"
                        . "</table>"
                        . "<hr>"
                        . "</div>"
                        . "<div style='text-align: center;'>"
                        . ""
                        . "</div>"
                        . "<div>"
                        . "<p style='text-align: center; font-family: Tahoma; font-size: 13px; line-height: 21px; padding: 0px 15px 10px;'>If you are having any issues with your account, please don't hesitate to contact us by replying to this mail. Thanks!</p><p style='    text-align: center; font-family: Tahoma; font-size: 11px; line-height: 21px; padding: 4px 15px 8px; background-color: #efefef; margin-bottom: 0;'>You're receiving this email because you have an account in LOTSFX, If you are not sure why you're receiving this, please contact us.</p>"
                        . "</div>"
                        . "</div>";



                if (!$mail->send()) {
//                    $json["msg"] = 'Message could not be sent.';
//                    $json["msg"] = 'error' . $mail->ErrorInfo;
                } else {
//                    $json["msg"] = 'Message has been sent';
                }
//
//
////         
                $json["msg"] = "Request Successful.<br/>An E-mail sent to your account with verification information.";
            } else {
                $json['msg_type'] = "ERR";
                $json['msg'] = "No Results Found Please Try Again";
            }
        } else {
            $json['msg_type'] = "ERR";
            $json['msg'] = "Invalid Email Address Please Check";
        }
    } else {
        $json['msg_type'] = "ERR";
        $json['msg'] = "Enter Email Please";
    }
    echo json_encode($json);

    exit();
}

function _dj_ltfx_register_user() {
    $json = array();
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    $name = $_POST["name"];
    $email = $_POST["email"];
    $number = $_POST["number"];
    $country = $_POST["country"];
    if (isset($_POST["country-code"])) {
        $code_country = $_POST["country-code"];
    } else {
        $code_country = '+94';
    }

    $password = "";

    if (!empty($name)) {
        if (!empty($email)) {
            if (is_email($email)) {
                if (!empty($number) && strlen($number) >= 9) {
                    if (!empty($country)) {
                        global $wpdb;
                        global $table_name;

                        $row = $wpdb->get_row("SELECT * FROM $table_name WHERE email='$email'");
                        if (empty($row)) {
                            $password = wp_generate_password(8, FALSE);
//                            $password = 'admin';
                            $data = array(
                                "name" => $name,
                                "email" => $email,
                                "code_country" => $code_country,
                                "phone" => $number,
                                "country" => $country,
                                "password" => md5($password),
                                "created_on" => date("Y-m-d H:i:s"),
                                "status" => 0,
                                "other" => $password
                            );
                            $wpdb->insert($table_name, $data);
                            $json["msg_type"] = "00";
                            $json["url"] = site_url("login");
                            $json["return_val"] = $password;
//mails
                            $mail = new PHPMailer();
                            $mail->isSMTP();

                            $mail->Host = "secure232.servconfig.com";  // specify main and backup server
                            $mail->Port = 587;
                            $mail->SMTPSecure = 'tls';


                            $mail->SMTPAuth = true;     // turn on SMTP authentication
                            $mail->Username = "register@lotsfx.com";  // SMTP username
                            $mail->Password = 'lots2018'; // SMTP password
//                            $mail->Username = "password@lotsfx.com";  // SMTP username
//                            $mail->Password = '2u=D_c#]WP3j'; // SMTP password

                            $mail->From = "register@lotsfx.com";
                            $mail->setFrom('register@lotsfx.com', 'Lotsfx');


                            $mail->AddAddress("$email", "$name");


                            $mail->IsHTML(true);                                  // set email format to HTML
                            $mail->Subject = "LOTSFX LOGIN DETAIL";
                            $mail->Body = "<div style='width: 500px; margin: 0 auto; border: 1px solid #dadada; box-shadow: 0px 0px 5px 0px #ececec;'>"
                                    . "<div style='text-align: center;'>"
                                    . "<a href='https://www.lotsfx.com/'>"
                                    . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/07/logo.png'>"
                                    . "</a></div>"
                                    . "<div style='text-align: center; padding: 27px 5px 8px; margin: 30px 1px; color: #d4d4d4; background: linear-gradient(to bottom right, #313131, #173058); font-family: monospace;'>"
                                    . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/08/check.png'>"
                                    . "<h2>LOTSFX REGISTRATION</h2>"
                                    . "</div><div style='padding: 0px 30px;'>"
                                    . "<h3>Hi $name</h3>"
                                    . "<p>Thank You for Creating a trading account with LOTSFX.</p>"
                                    . "<p>Your Login</p>"
                                    . "<table style='width: 100%;'>"
                                    . "<tr>"
                                    . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>User Name</td>"
                                    . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>$email</td>"
                                    . "</tr>"
                                    . "<tr>"
                                    . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>New Password</td>"
                                    . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>$password</td>"
                                    . "</tr>"
                                    . "</table>"
                                    . "<hr>"
                                    . "</div>"
                                    . "<div style='text-align: center;'>"
                                    . "<a href='https://www.lotsfx.com/login/' style='background-color: #d62f32; padding: 10px; border-radius: 4px; display: inline-block; margin: 15px 0px; text-decoration: none; font-size: 15px; font-family: Tahoma; color: white;'>LOGIN TO YOUR ACCOUNT</a>"
                                    . "</div>"
                                    . "<div><div style='padding: 0px 30px;'>"
//                                    . "<p>Risk warning and Important information</p>"
//                                    . "<ol>"
//                                    . "<li>Always keep your account details safe.</li>"
//                                    . "<li>Never disclose your login details to anyone.</li>"
//                                    . "<li>Should you suspect someone is using your account illegally, please notify us immediately.</li>"
//                                    . "</ol>"
                                    . "<p style='text-align: center; font-family: Tahoma; font-size: 13px; line-height: 21px; padding: 0px 15px 10px;'>If you are having any issues with your account, please dont hesitate to contact us by support@lotsfx.com. Thanks!</p>"
                                    . "<p>Happy Trading! <br>Best Regards <br> LOTSFX Team</p>"
                                    . "<p >Youre receiving this email because you have an account in LOTSFX, If you are not sure why youre receiving this, please contact us by support@lotsfx.com.</p>"
                                    . "</div></div>"
                                    . "</div>";



                            if (!$mail->send()) {
//                    $json["msg"] = 'Message could not be sent.';
//                    $json["msg"] = 'error' . $mail->ErrorInfo;
                            } else {
//                    $json["msg"] = 'Message has been sent';
                            }
//mails
                            $mail = new PHPMailer();
                            $mail->isSMTP();

                            $mail->Host = "secure232.servconfig.com";  // specify main and backup server
                            $mail->Port = 587;
                            $mail->SMTPSecure = 'tls';


                            $mail->SMTPAuth = true;     // turn on SMTP authentication
                            $mail->Username = "register@lotsfx.com";  // SMTP username
                            $mail->Password = 'lots2018'; // SMTP password
//                            $mail->Username = "password@lotsfx.com";  // SMTP username
//                            $mail->Password = '2u=D_c#]WP3j'; // SMTP password

                            $mail->From = "register@lotsfx.com";
                            $mail->setFrom('register@lotsfx.com', 'Lotsfx');


                            $mail->AddAddress("register@lotsfx.com", "Admin");


                            $mail->IsHTML(true);                                  // set email format to HTML
                            $mail->Subject = "LOTSFX LOGIN DETAIL";
                            $mail->Body = "<div style='width: 500px; margin: 0 auto; border: 1px solid #dadada; box-shadow: 0px 0px 5px 0px #ececec;'>"
                                    . "<div style='text-align: center;'>"
                                    . "<a href='https://www.lotsfx.com/'>"
                                    . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/07/logo.png'>"
                                    . "</a></div>"
                                    . "<div style='text-align: center; padding: 27px 5px 8px; margin: 30px 1px; color: #d4d4d4; background: linear-gradient(to bottom right, #313131, #173058); font-family: monospace;'>"
                                    . "<img src='https://www.lotsfx.com/wp-content/uploads/2018/08/check.png'>"
                                    . "<h2>LOTSFX REGISTRATION</h2>"
                                    . "</div><div style='padding: 0px 30px;'>"
                                    . "<h3>New User Registered</h3>"
                                    . "<table style='width: 100%;'>"
                                    . "<tr>"
                                    . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>User Name</td>"
                                    . "<td style='padding: 8px 2px; border-bottom: 1px solid #d4d4d4; font-family: Tahoma; font-size: 15px;'>$email</td>"
                                    . "</tr>"
                                    . "<tr>"
                                    . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>New Password</td>"
                                    . "<td style='padding: 8px 2px; font-family: Tahoma; font-size: 14px;'>$password</td>"
                                    . "</tr>"
                                    . "</table>"
                                    . "<hr>"
                                    . "</div>"
                                    . "<div style='text-align: center;'>"
                                    . ""
                                    . "</div>"
                                    . "<div>"
                                    . "<p style='text-align: center; font-family: Tahoma; font-size: 13px; line-height: 21px; padding: 0px 15px 10px;'>If you are having any issues with your account, please don't hesitate to contact us by replying to this mail. Thanks!</p><p style='    text-align: center; font-family: Tahoma; font-size: 11px; line-height: 21px; padding: 4px 15px 8px; background-color: #efefef; margin-bottom: 0;'>You're receiving this email because you have an account in LOTSFX, If you are not sure why you're receiving this, please contact us.</p>"
                                    . "</div>"
                                    . "</div>";



                            if (!$mail->send()) {
//                    $json["msg"] = 'Message could not be sent.';
//                    $json["msg"] = 'error' . $mail->ErrorInfo;
                            } else {
//                    $json["msg"] = 'Message has been sent';
                            }

                            $json["msg"] = "Registration Successful.<br/>An E-mail sent to your account with verification information.";
                        } else {
                            $json["msg_type"] = "ERR";
                            $json["msg"] = "E-mail is already associate with an Account.Try Login.";
                        }
                    } else {
                        $json["msg_type"] = "ERR";
                        $json["msg"] = "Country Field is Required.";
                    }
                } else {
                    $json["msg_type"] = "ERR";
                    $json["msg"] = "Invalid Telephone Number.";
                }
            } else {
                $json["msg_type"] = "ERR";
                $json["msg"] = "Invalid E-mail Field.";
            }
        } else {
            $json["msg_type"] = "ERR";
            $json["msg"] = "E-mail Field is Required.";
        }
    } else {
        $json["msg_type"] = "ERR";
        $json["msg"] = "Name Field is Required.";
    }
    echo json_encode($json);
    exit();
}

function _dj_ltfx_login_user() {

    $json = array();

    $email = $_POST["email"];
    $password = $_POST["password"];

    if (!empty($email)) {
        global $wpdb;
        global $table_name;

        $row = $wpdb->get_row("SELECT * FROM $table_name WHERE email='$email'");

        if (!empty($row)) {
            if (md5($password) == $row->password) {
                $json["msg_type"] = "00";
                $json["msg"] = "Login Successful";
                $user_id = $row->id;
                $user_name = $row->name;
                $user_email=$row->email;
//// Store Session Data
                $_SESSION['is_looged'] = TRUE;
                $_SESSION['id_user'] = $user_id;
                $_SESSION['user_name'] = $user_name;
                $today = date("Y-m-d H:i:s");
                $row2 = $wpdb->get_row("UPDATE wp_ltfx_users SET status = '1',timestamp='$today' WHERE (id = '$user_id')");
                $json['user_email'] = $user_email;
                $json['user_name'] = $user_name;
                $json["url"] = site_url("my-account");
            } else {
                $json["msg_type"] = "ERR";
                $json["msg"] = "Invalid Login.";
            }
        } else {
            $json["msg_type"] = "ERR";
            $json["msg"] = "Invalid Login.";
        }
    } else {
        $json["msg_type"] = "ERR";
        $json["msg"] = "E-mail Field is Required.";
    }
    echo json_encode($json);
    exit();
}

//wp admin
add_action('admin_menu', 'ltfx_user_setup_menu');

function ltfx_user_setup_menu() {
    add_menu_page('User Management', 'User Details', 'manage_options', 'user_plugin', 'ltfx_user_init');
}

function ltfx_user_init() {

//    $current_views = $this->views[current_filter()];
    include(dirname(__FILE__) . '/templates/user_details_list.php');
}
