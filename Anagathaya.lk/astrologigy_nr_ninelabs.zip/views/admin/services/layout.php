<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 content-holder">
            <h3><img src="<?php echo plugins_url('astrologigy_nr_ninelabs/icons/customer64.png'); ?>" alt="" width="2%"> Astrology Service Manager</h3>
        </div>
    </div>
    <div class="row">
        <?php include 'templates/curd_services.php'; ?>
        <?php include 'templates/list_services.php'; ?>
    </div>
</div>