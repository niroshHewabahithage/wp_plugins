<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 content-holder">
            <h3><img src="<?php echo plugins_url('astrologigy_nr_ninelabs/icons/employee.png'); ?>" alt="" width="2%"> Astrologists Management</h3>
        </div>
    </div>
    <div class="row">
        <?php include 'templates/curd_users.php'; ?>
        <?php include 'templates/list_users.php'; ?>
    </div>
</div>