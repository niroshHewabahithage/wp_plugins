<?php

class Load_requirements {

    public function __construct() {
        
    }

}
