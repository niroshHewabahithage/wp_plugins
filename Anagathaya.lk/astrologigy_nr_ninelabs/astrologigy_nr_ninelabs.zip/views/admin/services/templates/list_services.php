<div class="col-lg-8">
    <?php
    echo $template;
    ?>
</div>
