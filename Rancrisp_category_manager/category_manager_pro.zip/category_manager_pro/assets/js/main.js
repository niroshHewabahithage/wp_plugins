//@authur Nirosh Randimal

jQuery.noConflict();
(function ($) {
    $(function () {
        $(document).ready(function () {
         //   window.alert($(window).width() );
        });

    });
})(jQuery);


