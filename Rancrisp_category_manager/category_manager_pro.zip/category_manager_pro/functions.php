<?php

/*
  Plugin Name: Category Manager Pro
  Plugin URI: http://weblankan.com
  Description: Manages categories and products in the system
  Version: 1.0
  Author: Nirosh Randimal
  Author URI: www.linkedin.com/in/nirosh-randimal-331598146
  License: GPL2
 */

global $me_db_version;
global $folder;
global $site_url;
global $uri_segnemt;
global $limit;
global $table_name;
global $rncrp_db_version;

$rncrp_db_version = '1.0.0';
$folder = 'rancrisp';
$uri_segnemt = 5;
$limit = 5;
global $wpdb;
$table_name = $wpdb->prefix . "info_logs";

function _nr_rancrsp_category_authentication_init() {
    global $table_name;
    global $rncrp_db_version;
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
                    `log_id`  int(11) NOT NULL AUTO_INCREMENT ,
                `log_message`  varchar(255) NOT NULL ,
                `other`  varchar(255) NOT NULL ,
                PRIMARY KEY (`log_id`)
	) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta($sql);
}

register_activation_hook(__FILE__, '_nr_rancrsp_category_authentication_init');
register_activation_hook(__FILE__, '_nr_rancrsp_category_my_activation_func');

function _nr_rancrsp_category_my_activation_func() {
    file_put_contents(__DIR__ . '/my_loggg.txt', ob_get_contents());
}

function nr_rancrsp_category_homepage_view() {
    wp_enqueue_style('_nr_rancrsp-main', plugins_url('assets/css/main.css', __FILE__));
    wp_enqueue_script('_nr_rancrsp-homepage-view', plugins_url("assets/js/main.js", __FILE__), array('jquery'), 1.1, true);

    wp_localize_script('_nr_rancrsp_category-view', 'the_ajax_script', array('ajaxurl' => admin_url('admin-ajax.php')));
    ob_start();
    include (__DIR__ . "/template/homapeage_category.php");
    return ob_get_clean();
}

add_shortcode('front-category', 'nr_rancrsp_category_homepage_view');


