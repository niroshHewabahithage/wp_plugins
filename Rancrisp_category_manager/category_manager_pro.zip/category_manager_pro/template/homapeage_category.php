<?php

$taxonomy = 'product_cat';
$orderby = 'name';
$show_count = 0;      // 1 for yes, 0 for no
$pad_counts = 0;      // 1 for yes, 0 for no
$hierarchical = 1;      // 1 for yes, 0 for no  
$title = '';
$empty = 0;

$args = array(
    'taxonomy' => $taxonomy,
    'orderby' => $orderby,
    'show_count' => $show_count,
    'pad_counts' => $pad_counts,
    'hierarchical' => $hierarchical,
    'title_li' => $title,
    'image_id', true,
    'hide_empty' => $empty
);
$all_categories = get_categories($args);
//echo '<pre>';
//print_r($all_categories);
//echo '</pre>';


$thumbnail_id = get_woocommerce_term_meta('22', 'thumbnail_id', true);

$image = wp_get_attachment_url($thumbnail_id);

$div = "";
$div .= "<div class='row wooden-svg'>";

$x = 0;
foreach ($all_categories as $__value) {

   $thumbnail_id = get_woocommerce_term_meta($__value->term_id, 'thumbnail_id', true);
    $image = wp_get_attachment_url($thumbnail_id);
    if ($__value->name != 'Uncategorized') {
        if ($__value->category_parent == "0") {
            $x++;
            $div .= "<div class='col-lg-4 col-md-4 col-sm-12'>";
            $div .= "<div class='product_box text-center'>";
            $div .= "<h2 class='home-cat-name'>" . $__value->name ."</h2>";
            $div .= "<a href='".$site_url."product-category/$__value->slug'' class='btn-rancrips-catag'>View Products</a>";
            $div .= "<img src='" . $image . "' width='100%'>";
            $div .= "</div>";
            $div .= "</div>";
            if ($x == 3) {
				$div .="<div class='col-sm-12 wooden'><img src='".site_url('wp-content/uploads/2019/02/Shelf-1.png')."'></div>";
                $div .= "</div>";
                $div .= "<div class='row wooden-svg'>";
                $x = 0;
            }
        } else {
            
        }
    } else {
        // $x = 0;
    }
}

$div .= "</div>";

echo $div;


