<div class="col-lg-6">
    <?php
    echo $template;
    ?>
</div>