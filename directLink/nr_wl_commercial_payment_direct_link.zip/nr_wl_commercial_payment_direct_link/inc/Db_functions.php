<?php

class Db_functions {

    private $db_prefix_plu;

    function __construct() {
        $this->db_prefix_plu = "lw_lrgnd_";
    }

    function get_value_single($tbl_name, $ref_num = '', $o_email = '') {        
        global $wpdb;
        $table_name = $wpdb->prefix . $tbl_name;
        $row = $wpdb->get_row("SELECT * FROM $table_name where refno='$ref_num' AND email='$o_email'");
        return $row;
    }

}
