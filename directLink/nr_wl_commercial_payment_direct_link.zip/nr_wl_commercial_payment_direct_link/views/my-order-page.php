<?php
if ($get_single_reuqest != "") {
    ?>
    <?php
    $merchant_id = "";
    $merchant_currency = "";
    $total_price = "";
//echo $meta_0->key;

    $merchant_id = 'TESTDIRECTLINLKR';
    $merchant_currency = 'LKR';
    $total_price = $get_single_reuqest->adpayment;


    $order_country = "";

    $return_url = get_home_url() . '/thank-you-page';

//echo $return_url;
    $headers = array(
        "cache-control: no-cache",
        'Authorization: Basic bWVyY2hhbnQuVEVTVERJUkVDVExJTkxLUjo2OTA5OTQ2OWJkNTc3NTg5M2RhYjdhMmQyYmJhYjhjNw=='
    );

    $payload_array = array(
        "apiOperation" => "CREATE_CHECKOUT_SESSION",
        "order" => array(
            "amount" => $total_price,
            "currency" => "$merchant_currency",
            "description" => "Ordered goods",
            "id" => "$ref_no"
        ),
        "interaction" => array("returnUrl" => "$return_url")
    );

//echo '<pre>';
//print_r($payload_array);
//echo '</pre>';
    $url = "https://cbcmpgs.gateway.mastercard.com/api/rest/version/51/merchant/$merchant_id/session";
//$url = "https://test-gateway.mastercard.com/api/rest/version/51/merchant/TESTRANCRISPCLKR/session";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload_array));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $result = curl_exec($ch);
    curl_close($ch);

    $decoded_data = json_decode($result);
//echo '<pre>';
//print_r($decoded_data);
//echo '</pre>';
//    echo $decoded_data->session->id

    $image_path = plugins_url('../assests/images/pay.jpg', __FILE__);
    ?>
    <style>
        .pay_btn_com{
            background: #006eb9;
            padding: 4px 14px;
            color: #fff;
            border: none;
            border-radius: 5px;
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!--<script src="https://test-gateway.mastercard.com/checkout/version/51/checkout.js"-->
    <script src="https://cbcmpgs.gateway.mastercard.com/checkout/version/51/checkout.js"
            data-error="errorCallback"
            data-cancel="cancelCallback">
    </script>

    <script type="text/javascript">
        function errorCallback(error) {
            console.log(error);
        }

        function cancelCallback() {
            console.log('Payment cancelled');
        }

        Checkout.configure({
            merchant: '<?php echo $merchant_id; ?>',
            order: {
                amount: function () {
                    //Dynamic calculation of amount
                    return <?php echo $total_price; ?>;
                },
                currency: '<?php echo $merchant_currency; ?>',
                description: 'Ordered goods',
                id: '<?php echo $ref_no; ?>'
                        //                    id: '11'
            },
            session: {
                id: '<?php echo $decoded_data->session->id ?>'
            },
            interaction: {
                merchant: {
                    name: 'nirosh Randimal',
                    address: {
                        line1: 'hellow World',
                        line2: '1234 Example Town'
                    }
                }
            }
        });
        $(document).ready(function () {

            $("#primary").addClass("col-md-12").removeClass("col-md-8");
            $("#primary").find('.crt_header').hide();
            $("#primary").find('.woocommerce-message').hide();
            $("#tabel_id").show(500);
            $(".remove").hide();
            $("#primary").find(".qty").attr("disabled", "disabled");
            $("#primary").find(".actions").hide();
            $("#id_terms_and_condition").show(500);

            $("#defaultUnchecked").click(function () {
                if ($(this).is(':checked')) {
                    $("#button-pay").show(500);
                } else {
                    $("#button-pay").hide(500);
                }
            });
        });
    </script>
    <div class="container" style="padding: 25px 15px;">

        <div class="row well">
            <legend>My Order Details</legend>
            <div class=" col-lg-offset-2 col-lg-8" >
                    <!--<form class="form-horizontal" action="<?php echo $url ?>" method="POST">                    -->
                <style>
                    table > tbody > tr > td{border: none!important;}
                </style>
                <table class="table table-hover table-condensed table-striped">
                    <tr>
                        <td class="text-right" style="width: 40%">Customer Name</td>
                        <td><p class="form-control-static"><b><?php echo $get_single_reuqest->custname ?></b></p></td>
                    </tr>
                    <tr>
                        <td class="text-right">Package Amount</td>
                        <td><p class="form-control-static"><b><?php echo $get_single_reuqest->amount ?></b></p></td>
                    </tr>
                    <tr>
                        <td class="text-right">Advance Payment Percentage</td>
                        <td><p class="form-control-static"><b><?php echo $get_single_reuqest->percentage ?>%</b></p></td>
                    </tr>
                    <tr>
                        <td class="text-right">Advance Payment</td>
                        <td><p class="form-control-static"><b><?php echo $get_single_reuqest->adpayment ?></b></p></td>
                    </tr>
                    <tr>
                        <td class="text-right">Description</td>
                        <td><p class="form-control-static"><b><?php echo $get_single_reuqest->notes ?></b></p></td>
                    </tr>

                </table>
                <!--</form>-->
            </div>
        </div>
        <div class='row' id="id_terms_and_condition" style='display:none'>

            <div class='col-lg-6 col-md-6 col-sm-12 col-xs-12'>

                <input type="checkbox" class="custom-control-input" id="defaultUnchecked">
                <label class="custom-control-label" for="defaultUnchecked" style="display: inline-block">&nbsp;I agree to the <a href="<?php echo home_url(); ?>" target="_blank">Direct Link</a>
                    Terms and Conditions</label>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 gutter-no" id="button-pay"  style="display: none">
                <input type="button" class='pay_btn_com' value="Pay Now Using" onclick="Checkout.showLightbox();" />
                <img src='<?php echo $image_path; ?>' class='payment_image' alt='payment_image_represet' width='50%'>

            </div>
        </div>
        <div class="row" >

        </div>
        <?php
    } else {
        ?>
        <div class="row">
            <div class=" col-lg-offset-3 col-lg-6" >
                <h2>Nothings Found.</h2>
            </div>
        </div>
        <?php
    }
    ?>
</div>

