<?php

/*
  Plugin Name: Directlink_pay_by_directlink
  Plugin URI: https://www.weblankan.com
  Description: A Payment Gateway for the Directlink purchase data
  Version: 1.0
  Author: niroroo619- Nirosh Randimal
  Author URI: www.linkedin.com/in/nirosh-randimal-331598146
  License: GPL2
 */
global $me_db_version;
global $wpdb;

include plugin_dir_path(__FILE__) . 'inc/Db_functions.php';

add_shortcode("payment_gateway_view", "nr_payment_gateway_view");

function nr_payment_gateway_view() {
    $ref_no = $_SESSION["o_ref_no"];
    $o_email = $_SESSION["o_email"];

    //importing db Model
    $db_c = new Db_functions();
    $get_single_reuqest = $db_c->get_value_single("payment", $ref_no, $o_email);
    include ('views/my-order-page.php');
}
