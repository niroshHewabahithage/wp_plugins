-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: 192.168.8.102    Database: laagrand
-- ------------------------------------------------------
-- Server version	5.7.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lw_lrgnd_age_groups`
--

DROP TABLE IF EXISTS `lw_lrgnd_age_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_age_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `age_group` varchar(45) DEFAULT NULL,
  `age_description` text,
  `logic` varchar(45) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_age_groups`
--

LOCK TABLES `lw_lrgnd_age_groups` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_age_groups` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_age_groups` VALUES (1,'Adult','Age More than 20','1',1),(2,'Young','Age 6 to 19','0.5',1),(3,'Child','Age Below 6','0',1);
/*!40000 ALTER TABLE `lw_lrgnd_age_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_custom_additional_feilds`
--

DROP TABLE IF EXISTS `lw_lrgnd_custom_additional_feilds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_custom_additional_feilds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) DEFAULT NULL,
  `short_code` text,
  `custom_values` text,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_custom_additional_feilds`
--

LOCK TABLES `lw_lrgnd_custom_additional_feilds` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_custom_additional_feilds` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_custom_additional_feilds` VALUES (4,4,'easy-rafting-for-fam','a:7:{s:10:\"item_price\";s:5:\"12300\";s:11:\"adult_logic\";s:1:\"1\";s:12:\"Desired_Time\";s:7:\"morning\";s:11:\"child_logic\";s:3:\"0.5\";s:6:\"adults\";s:2:\"50\";s:6:\"childs\";s:2:\"85\";s:11:\"final_price\";s:8:\"26137500\";}',1),(5,4,'easy-rafting-for-fam','a:7:{s:10:\"item_price\";s:5:\"12300\";s:11:\"adult_logic\";s:1:\"1\";s:12:\"Desired_Time\";s:7:\"morning\";s:11:\"child_logic\";s:3:\"0.5\";s:6:\"adults\";s:2:\"50\";s:6:\"childs\";s:2:\"85\";s:11:\"final_price\";s:8:\"26137500\";}',1),(6,14,'easy-rafting-for-fam','a:7:{s:10:\"item_price\";s:5:\"12300\";s:11:\"adult_logic\";s:1:\"1\";s:12:\"Desired_Time\";s:7:\"morning\";s:11:\"child_logic\";s:3:\"0.5\";s:6:\"adults\";s:2:\"50\";s:6:\"childs\";s:2:\"85\";s:11:\"final_price\";s:8:\"26137500\";}',1),(7,0,'','s:0:\"\";',1),(8,17,'backwards-jump','a:6:{s:10:\"item_price\";s:3:\"900\";s:11:\"adult_logic\";s:1:\"1\";s:6:\"adults\";s:2:\"12\";s:11:\"child_logic\";s:3:\"NaN\";s:6:\"childs\";s:2:\"23\";s:11:\"final_price\";s:6:\"124200\";}',1),(9,20,'interlaken-majestic-','a:8:{s:10:\"item_price\";s:4:\"8000\";s:12:\"Desired_Time\";s:14:\"08:00 to 11:30\";s:11:\"adult_logic\";s:1:\"1\";s:6:\"adults\";s:2:\"15\";s:11:\"child_logic\";s:3:\"0.5\";s:6:\"childs\";s:3:\"123\";s:12:\"wish_to_jump\";s:6:\"single\";s:11:\"final_price\";s:7:\"7380000\";}',1),(10,0,'','s:0:\"\";',1),(11,0,'','s:0:\"\";',1),(12,4,'whole-day-trip','a:6:{s:10:\"item_price\";s:3:\"500\";s:12:\"Travel_model\";s:1:\"1\";s:12:\"travel_class\";s:1:\"2\";s:14:\"item_reduction\";s:1:\"4\";s:20:\"item_reduction_price\";s:2:\"70\";s:9:\"reduction\";s:1:\"2\";}',1),(13,21,'whole-day-trip','a:6:{s:10:\"item_price\";s:3:\"500\";s:12:\"Travel_model\";s:1:\"1\";s:12:\"travel_class\";s:1:\"2\";s:14:\"item_reduction\";s:1:\"4\";s:20:\"item_reduction_price\";s:2:\"70\";s:9:\"reduction\";s:1:\"2\";}',1),(14,0,'swiss-travel-pass','a:13:{s:15:\"passport_number\";s:11:\"aefaefawawd\";s:12:\"ticket_model\";s:23:\"Swiss Travel Pass Youth\";s:12:\"sts_required\";s:2:\"No\";s:9:\"companion\";s:0:\"\";s:7:\"surname\";s:0:\"\";s:7:\"dob_com\";s:0:\"\";s:7:\"child_1\";s:0:\"\";s:15:\"child_surname_1\";s:0:\"\";s:9:\"dob_chi_1\";s:0:\"\";s:7:\"child_2\";s:0:\"\";s:15:\"child_surname_2\";s:0:\"\";s:9:\"dob_chi_2\";s:0:\"\";s:11:\"final_price\";s:4:\"5000\";}',1),(15,0,'swiss-travel-pass','a:13:{s:15:\"passport_number\";s:11:\"aefaefawawd\";s:12:\"ticket_model\";s:23:\"Swiss Travel Pass Youth\";s:12:\"sts_required\";s:3:\"yes\";s:9:\"companion\";s:0:\"\";s:7:\"surname\";s:0:\"\";s:7:\"dob_com\";s:0:\"\";s:7:\"child_1\";s:0:\"\";s:15:\"child_surname_1\";s:0:\"\";s:9:\"dob_chi_1\";s:0:\"\";s:7:\"child_2\";s:0:\"\";s:15:\"child_surname_2\";s:0:\"\";s:9:\"dob_chi_2\";s:0:\"\";s:11:\"final_price\";s:4:\"5000\";}',1),(16,22,'swiss-travel-pass','a:13:{s:15:\"passport_number\";s:11:\"aefaefawawd\";s:12:\"ticket_model\";s:23:\"Swiss Travel Pass Youth\";s:12:\"sts_required\";s:3:\"yes\";s:9:\"companion\";s:6:\"aefaef\";s:7:\"surname\";s:6:\"aefaef\";s:7:\"dob_com\";s:10:\"2019-09-03\";s:7:\"child_1\";s:6:\"aefaef\";s:15:\"child_surname_1\";s:6:\"aefaef\";s:9:\"dob_chi_1\";s:10:\"2019-08-26\";s:7:\"child_2\";s:6:\"aefaef\";s:15:\"child_surname_2\";s:9:\"aefaefaef\";s:9:\"dob_chi_2\";s:10:\"2019-09-02\";s:11:\"final_price\";s:4:\"5000\";}',1),(17,24,'swiss-travel-pass','a:13:{s:15:\"passport_number\";s:11:\"aefaefawawd\";s:12:\"ticket_model\";s:23:\"Swiss Travel Pass Youth\";s:12:\"sts_required\";s:3:\"yes\";s:9:\"companion\";s:6:\"aefaef\";s:7:\"surname\";s:6:\"aefaef\";s:7:\"dob_com\";s:10:\"2019-09-03\";s:7:\"child_1\";s:6:\"aefaef\";s:15:\"child_surname_1\";s:6:\"aefaef\";s:9:\"dob_chi_1\";s:10:\"2019-08-26\";s:7:\"child_2\";s:6:\"aefaef\";s:15:\"child_surname_2\";s:9:\"aefaefaef\";s:9:\"dob_chi_2\";s:10:\"2019-09-02\";s:11:\"final_price\";s:4:\"5000\";}',1),(18,26,'swiss-travel-pass','a:13:{s:15:\"passport_number\";s:11:\"aefaefawawd\";s:12:\"ticket_model\";s:23:\"Swiss Travel Pass Youth\";s:12:\"sts_required\";s:3:\"yes\";s:9:\"companion\";s:6:\"aefaef\";s:7:\"surname\";s:6:\"aefaef\";s:7:\"dob_com\";s:10:\"2019-09-03\";s:7:\"child_1\";s:6:\"aefaef\";s:15:\"child_surname_1\";s:6:\"aefaef\";s:9:\"dob_chi_1\";s:10:\"2019-08-26\";s:7:\"child_2\";s:6:\"aefaef\";s:15:\"child_surname_2\";s:9:\"aefaefaef\";s:9:\"dob_chi_2\";s:10:\"2019-09-02\";s:11:\"final_price\";s:4:\"5000\";}',1),(19,4,'laucerne-interlaken-','s:0:\"\";',1),(20,4,'laucerne-interlaken-','s:0:\"\";',1),(21,4,'laucerne-interlaken-','a:3:{s:12:\"travel_model\";s:1:\"9\";s:9:\"reduction\";s:2:\"18\";s:11:\"final_price\";s:4:\"4950\";}',1),(22,27,'laucerne-interlaken-','a:3:{s:12:\"travel_model\";s:1:\"9\";s:9:\"reduction\";s:2:\"19\";s:11:\"final_price\";s:4:\"4845\";}',1),(23,4,'interlaken-montreux-','a:3:{s:12:\"travel_model\";s:2:\"16\";s:9:\"reduction\";s:2:\"22\";s:11:\"final_price\";s:4:\"2500\";}',1),(24,28,'interlaken-montreux-','a:3:{s:12:\"travel_model\";s:2:\"16\";s:9:\"reduction\";s:2:\"23\";s:11:\"final_price\";s:4:\"2880\";}',1),(25,0,'','s:0:\"\";',1),(26,0,'swiss-smart-travel-p','a:16:{s:15:\"passport_number\";s:9:\"aefaefaef\";s:12:\"travel_class\";s:9:\"1st Class\";s:6:\"extras\";s:15:\"aefaefaefaefaef\";s:12:\"first_name_1\";s:6:\"awdawd\";s:11:\"last_name_1\";s:3:\"awd\";s:9:\"address_1\";s:6:\"awdawd\";s:7:\"phone_1\";s:5:\"awdaw\";s:7:\"email_1\";s:7:\"dawdawd\";s:11:\"date_of_b_1\";s:0:\"\";s:12:\"first_name_2\";s:6:\"awdawd\";s:11:\"last_name_2\";s:3:\"awd\";s:9:\"address_2\";s:6:\"wadawd\";s:7:\"phone_2\";s:6:\"awdawd\";s:7:\"email_2\";s:0:\"\";s:11:\"date_of_b_2\";s:0:\"\";s:11:\"final_price\";s:4:\"7855\";}',1),(27,30,'swiss-smart-travel-p','a:16:{s:15:\"passport_number\";s:9:\"aefaefaef\";s:12:\"travel_class\";s:9:\"1st Class\";s:6:\"extras\";s:15:\"aefaefaefaefaef\";s:12:\"first_name_1\";s:4:\"awda\";s:11:\"last_name_1\";s:4:\"dawd\";s:9:\"address_1\";s:6:\"awdawd\";s:7:\"phone_1\";s:6:\"awdawd\";s:7:\"email_1\";s:9:\"awdawdawd\";s:11:\"date_of_b_1\";s:0:\"\";s:12:\"first_name_2\";s:6:\"awdawd\";s:11:\"last_name_2\";s:5:\"awdaw\";s:9:\"address_2\";s:6:\"dawdaw\";s:7:\"phone_2\";s:7:\"dawdawd\";s:7:\"email_2\";s:9:\"awdawdawd\";s:11:\"date_of_b_2\";s:0:\"\";s:11:\"final_price\";s:4:\"7855\";}',1),(28,31,'swiss-smart-travel-p','a:10:{s:15:\"passport_number\";s:9:\"aefaefaef\";s:12:\"travel_class\";s:9:\"1st Class\";s:6:\"extras\";s:15:\"aefaefaefaefaef\";s:12:\"first_name_1\";s:6:\"awdawd\";s:11:\"last_name_1\";s:4:\"awda\";s:9:\"address_1\";s:5:\"wdawd\";s:7:\"phone_1\";s:6:\"awdawd\";s:7:\"email_1\";s:3:\"awd\";s:11:\"date_of_b_1\";s:0:\"\";s:11:\"final_price\";s:4:\"7855\";}',1);
/*!40000 ALTER TABLE `lw_lrgnd_custom_additional_feilds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_package_enrol_payment_registry`
--

DROP TABLE IF EXISTS `lw_lrgnd_package_enrol_payment_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_package_enrol_payment_registry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_enrall` int(11) DEFAULT NULL,
  `info_id` int(11) DEFAULT NULL,
  `payment_remoark` text,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_package_enrol_payment_registry`
--

LOCK TABLES `lw_lrgnd_package_enrol_payment_registry` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_package_enrol_payment_registry` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_package_enrol_payment_registry` VALUES (1,3,4,NULL,1),(2,4,4,NULL,1),(3,5,4,NULL,1),(4,6,4,NULL,1),(5,7,4,NULL,1),(6,8,4,NULL,1),(7,9,4,NULL,1),(8,10,4,NULL,1),(9,11,4,NULL,1),(10,12,4,NULL,1),(11,13,4,NULL,1),(12,14,4,NULL,1),(13,15,4,NULL,1),(14,16,4,NULL,1),(15,17,4,NULL,1),(16,18,4,NULL,1),(17,19,4,NULL,1),(18,20,4,NULL,1),(19,21,4,NULL,1),(20,22,4,NULL,1),(21,23,4,NULL,1),(22,24,4,NULL,1),(23,25,4,NULL,1),(24,26,4,NULL,1),(25,27,4,NULL,1),(26,28,4,NULL,1),(27,29,4,NULL,1),(28,30,4,NULL,1),(29,31,4,NULL,1),(30,32,4,NULL,1),(31,33,4,NULL,1),(32,34,4,NULL,1),(33,35,9,NULL,1),(34,36,11,NULL,1),(35,37,0,NULL,1),(36,38,29,NULL,1);
/*!40000 ALTER TABLE `lw_lrgnd_package_enrol_payment_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_package_enroll`
--

DROP TABLE IF EXISTS `lw_lrgnd_package_enroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_package_enroll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) DEFAULT NULL,
  `package_item_mode` int(11) DEFAULT NULL,
  `package_short_code` text,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_package_enroll`
--

LOCK TABLES `lw_lrgnd_package_enroll` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_package_enroll` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_package_enroll` VALUES (1,4,7,'connecting-pass-from',1),(2,4,7,'connecting-pass-from',1),(3,4,7,'connecting-pass-from',1),(5,4,7,'connecting-pass-from',1),(6,4,7,'connecting-pass-from',1),(7,4,7,'connecting-pass-from',1),(8,4,7,'connecting-pass-from',1),(9,4,7,'connecting-pass-from',1),(10,4,7,'connecting-pass-from',1),(11,4,7,'connecting-pass-from',1),(12,4,7,'connecting-pass-from',1),(13,4,7,'connecting-pass-from',1),(14,4,7,'connecting-pass-from',1),(15,4,7,'connecting-pass-from',1),(16,4,7,'connecting-pass-from',1),(17,4,7,'connecting-pass-from',1),(18,4,7,'connecting-pass-from',1),(19,4,7,'connecting-pass-from',1),(20,4,7,'connecting-pass-from',1),(21,4,7,'connecting-pass-from',1),(22,4,7,'connecting-pass-from',1),(23,4,7,'connecting-pass-from',1),(24,4,7,'connecting-pass-from',1),(25,4,7,'connecting-pass-from',1),(26,4,7,'connecting-pass-from',1),(27,4,7,'connecting-pass-from',1),(28,4,7,'connecting-pass-from',1),(29,4,7,'connecting-pass-from',1),(30,4,7,'connecting-pass-from',1),(31,4,7,'connecting-pass-from',1),(32,4,7,'connecting-pass-from',1),(33,4,7,'connecting-pass-from',1),(34,4,7,'connecting-pass-from',1),(35,9,7,'connecting-pass-from',1),(36,11,7,'connecting-pass-from',1),(37,0,18,'',1),(38,29,18,'gelmerbahn-steepest-',1);
/*!40000 ALTER TABLE `lw_lrgnd_package_enroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_package_users`
--

DROP TABLE IF EXISTS `lw_lrgnd_package_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_package_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_enroll` int(11) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `info_id` int(11) DEFAULT NULL,
  `reduction_id` int(11) DEFAULT NULL,
  `title` text,
  `first_name` text,
  `last_name` text,
  `gender` text,
  `dob` date DEFAULT NULL,
  `reduction` int(11) DEFAULT NULL,
  `package_price` text,
  `age_group` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_package_users`
--

LOCK TABLES `lw_lrgnd_package_users` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_package_users` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_package_users` VALUES (1,5,3,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',NULL,1),(2,6,4,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',NULL,1),(3,7,5,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',NULL,1),(4,8,6,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',NULL,1),(5,9,7,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',NULL,1),(6,10,8,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',NULL,1),(7,11,9,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',NULL,1),(8,12,10,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',NULL,1),(9,13,11,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',NULL,1),(10,14,12,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',15,'477',NULL,1),(11,15,13,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'600',2,1),(12,16,14,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'600',2,1),(13,17,15,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'600',2,1),(14,18,16,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',2,1),(15,19,17,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',2,1),(16,20,18,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'301',2,1),(17,21,19,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',13,'250',2,1),(18,22,20,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'150.5',2,1),(19,23,21,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'150.5',2,1),(20,24,22,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'150.5',2,1),(21,25,23,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'150.5',2,1),(22,26,24,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'150.5',2,1),(23,27,25,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'150.5',2,1),(24,28,26,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'150.5',2,1),(25,28,26,4,NULL,'Mr.','afaefaeaf','aefaefaef','male','2019-09-04',14,'150.5',2,1),(26,28,26,4,NULL,'Master','awdawd','awdawdawd','male','2019-09-12',15,'238.5',2,1),(27,29,27,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'150.5',2,1),(28,30,28,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',14,'150.5',2,1),(29,31,29,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',0,'150.5',2,1),(30,32,30,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',15,'238.5',2,1),(31,33,31,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',15,'238.5',2,1),(32,33,31,4,NULL,'Mr.','gsrgsrg','srgsrg','male','2019-09-04',14,'150.5',2,1),(33,34,32,4,NULL,'Mr.','Nirosh','Randimal','female','2004-09-10',15,'238.5',2,1),(34,34,32,4,NULL,'Mr.','srsrg','srgsrgsrg','male','2019-09-02',16,'238.5',2,1),(35,35,33,9,NULL,'Mr.','aefaef','aefaefaef','male','2004-09-18',14,'150.5',2,1),(36,36,34,11,NULL,'Mrs.','sefsef','sefsef','male','2004-09-18',14,'150.5',2,1),(37,36,34,11,NULL,'Mr.','dtrdhd','dhdth','male','2019-09-04',14,'150.5',2,1),(38,37,35,0,NULL,NULL,NULL,NULL,NULL,NULL,34,'1750',2,1),(39,37,35,0,NULL,'Mrs.','awdawd','awdawd','male','2019-09-05',34,'0',3,1),(40,38,36,29,NULL,'Mr.','wadawd','awdawdawd','male','2004-09-18',34,'1750',2,1),(41,38,36,29,NULL,'Mrs.','sefsef','sefsefsef','male','2019-09-11',35,'4800',1,1);
/*!40000 ALTER TABLE `lw_lrgnd_package_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_train_classes`
--

DROP TABLE IF EXISTS `lw_lrgnd_train_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_train_classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `train_class` varchar(45) DEFAULT NULL,
  `active` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_train_classes`
--

LOCK TABLES `lw_lrgnd_train_classes` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_train_classes` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_train_classes` VALUES (1,'1st Class',1),(2,'2nd Class',1);
/*!40000 ALTER TABLE `lw_lrgnd_train_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_train_destinations`
--

DROP TABLE IF EXISTS `lw_lrgnd_train_destinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_train_destinations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `departure_place` text,
  `departure_time` time DEFAULT NULL,
  `arrival_place` text,
  `arrival_time` time DEFAULT NULL,
  `short_code` text,
  `travel_model` varchar(45) DEFAULT NULL,
  `active` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_train_destinations`
--

LOCK TABLES `lw_lrgnd_train_destinations` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_train_destinations` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_train_destinations` VALUES (1,'Lugano ','10:00:00','Tirano(Italy)','13:00:00','whole-day-trip','Bus',1),(2,'Tirano(Italy)','14:25:00','Chur','18:25:00','whole-day-trip','Train',1),(3,'Chur','08:32:00','Tirano(Italy)','00:00:12','travel-to-luxurious-','Train',1),(4,'Tirano(Italy)','14:07:00','St.Moritz','16:19:00','travel-to-luxurious-','Train',1),(5,'Landquart','08:37:00','Tirano(Italy)','13:33:00','urban-to-classic-tow','Train',1),(6,'Tirano(Italy)','14:25:00','Chur','18:19:00','urban-to-classic-tow','Train',1),(7,'Interlaken Ost',NULL,'Jungfraujoch',NULL,'connecting-pass-from','Train',1),(8,'Interlaken West',NULL,'Jungfraujoch',NULL,'connecting-pass-from','Train',1),(9,'Lucerne','06:06:00','Interlaken','07:54:00','laucerne-interlaken-',NULL,1),(10,'Lucerne','07:06:00','Interlaken','08:55:00','laucerne-interlaken-',NULL,1),(11,'Lucerne','08:05:00','Interlaken','09:55:00','laucerne-interlaken-',NULL,1),(12,'Lucerne','09:06:00','Interlaken','10:55:00','laucerne-interlaken-',NULL,1),(13,'Interlaken Ost','07:04:00','Lucerne','08:55:00','interlaken-lucerne-e',NULL,0),(14,'Interlaken Ost','08:04:00','Lucerne','09:55:00','interlaken-lucerne-e',NULL,0),(15,'Interlaken Ost','09:04:00','Lucerne','10:55:00','interlaken-lucerne-e',NULL,0),(16,'Interlakem Ost','09:08:00','Zweisimmen............................Montreus ','12:13:00','interlaken-montreux-',NULL,0),(17,'Montreux','09:44:00','Zweisimmen............................Interlaken Ost','12:50:00','montreux-interlaken-',NULL,0),(18,NULL,'09:00:00',NULL,'11:00:00','gelmerbahn-steepest-',NULL,0),(19,NULL,'11:00:00',NULL,'13:00:00','gelmerbahn-steepest-',NULL,0),(20,NULL,'13:00:00',NULL,'15:00:00','gelmerbahn-steepest-',NULL,0),(21,NULL,'15:00:00',NULL,'17:00:00','gelmerbahn-steepest-',NULL,0);
/*!40000 ALTER TABLE `lw_lrgnd_train_destinations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_travel_categories`
--

DROP TABLE IF EXISTS `lw_lrgnd_travel_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_travel_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_name` text,
  `cate_slug` text,
  `active` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_travel_categories`
--

LOCK TABLES `lw_lrgnd_travel_categories` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_travel_categories` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_travel_categories` VALUES (7,'eafaef','aefaef',1),(8,'eafaef','aefaef',1);
/*!40000 ALTER TABLE `lw_lrgnd_travel_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_travel_package_reductions`
--

DROP TABLE IF EXISTS `lw_lrgnd_travel_package_reductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_travel_package_reductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reduction_id` int(11) DEFAULT NULL,
  `short_code` text,
  `reduction_price` varchar(45) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_travel_package_reductions`
--

LOCK TABLES `lw_lrgnd_travel_package_reductions` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_travel_package_reductions` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_travel_package_reductions` VALUES (1,1,'whole-day-trip','50',1),(2,2,'whole-day-trip','50',1),(3,3,'whole-day-trip','60',1),(4,4,'whole-day-trip','70',1),(5,1,'urban-to-classic-tow','80',1),(6,2,'urban-to-classic-tow','100',1),(7,3,'urban-to-classic-tow','15',1),(8,4,'urban-to-classic-tow','15',1),(9,1,'travel-to-luxurious-','13',1),(10,2,'travel-to-luxurious-','155',1),(11,3,'travel-to-luxurious-','156',1),(12,4,'travel-to-luxurious-','18',1),(13,1,'connecting-pass-from','100',NULL),(14,2,'connecting-pass-from','299',NULL),(15,3,'connecting-pass-from','123',NULL),(16,4,'connecting-pass-from','123',NULL),(17,1,'laucerne-interlaken-','50',NULL),(18,2,'laucerne-interlaken-','50',NULL),(19,3,'laucerne-interlaken-','155',NULL),(20,4,'laucerne-interlaken-','122',NULL),(21,1,'interlaken-montreux-','150',NULL),(22,2,'interlaken-montreux-','1500',NULL),(23,3,'interlaken-montreux-','1120',NULL),(24,4,'interlaken-montreux-','125',NULL),(25,1,'montreux-interlaken-','123',NULL),(26,2,'montreux-interlaken-','125',NULL),(27,3,'montreux-interlaken-','1564',NULL),(28,4,'montreux-interlaken-','158',NULL),(29,1,'interlaken-lucerne-e','1546',NULL),(30,2,'interlaken-lucerne-e','154',NULL),(31,3,'interlaken-lucerne-e','154',NULL),(32,4,'interlaken-lucerne-e','125',NULL),(33,1,'gelmerbahn-steepest-','1500',NULL),(34,2,'gelmerbahn-steepest-','1500',NULL),(35,3,'gelmerbahn-steepest-','200',NULL),(36,4,'gelmerbahn-steepest-','50',NULL);
/*!40000 ALTER TABLE `lw_lrgnd_travel_package_reductions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_travel_packages`
--

DROP TABLE IF EXISTS `lw_lrgnd_travel_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_travel_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` text,
  `package_slug` text,
  `package_price` text,
  `package_shortcode` text,
  `active` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_travel_packages`
--

LOCK TABLES `lw_lrgnd_travel_packages` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_travel_packages` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_travel_packages` VALUES (3,'Easy Rafting for Families','easy-rafting-for-families','12300','easy-rafting-for-fam',1),(4,'Swiss Alps Rafting','swiss-alps-rafting','5000','swiss-alps-rafting',1),(5,'Pleasure + Sportive','pleasure-sportive','500','pleasure-sportive',1),(6,'Swiss Grand Canyon Rafting for Families','swiss-grand-canyon-rafting-for-families','500','swiss-grand-canyon-r',1),(7,'Swiss Grand Canyon Rafting Full Day','swiss-grand-canyon-rafting-full-day','800','swiss-grand-canyon-r-not-fam',1),(8,'Easy Rafting Along With Swiss Urban Site','easy-rafting-along-with-swiss-urban-site','1200','easy-rafting-along-w',1),(9,'Backwards Jump','backwards-jump','900','backwards-jump',1),(10,'Speed Jump','speed-jump','700','speed-jump',1),(11,'Classic Jump','classic-jump','600','classic-jump',1),(12,'Swiss Alps Bungee Jump','swiss-alps-bungee-jump','300','swiss-alps-bungee-ju',1),(13,'Interlaken Majestic View','interlaken-majestic-view','8000','interlaken-majestic-',1),(14,'Interlaken Majestic View + Water Skiing','interlaken-majestic-view-water-skiing','21123','interlaken-majestic-12',1),(15,'Grindelwald Paragliding','grindelwald-paragliding','0986','grindelwald-paraglid',1),(16,'Lauterbrunnen Valley View','lauterbrunnen-valley-view','800','lauterbrunnen-valley',1),(17,'Spiez Paragliding','spiez-paragliding','1234','spiez-paragliding',1),(18,'Interlaken Paragliding','interlaken-paragliding','500','interlaken-paraglidi',1),(19,'Whole Day Trip','whole-day-trip','500','whole-day-trip',1),(20,'Travel to luxurious St.Moritz','travel-to-luxurious-stmoritz','1000','travel-to-luxurious-',1),(21,'Urban to Classic town','urban-to-classic-town','1234','urban-to-classic-tow',1),(22,'Connecting Pass from Interlaken','connecting-pass-from-interlaken','600','connecting-pass-from',1),(23,'Connecting Pass from Swiss Major Cities','connecting-pass-from-swiss-major-cities','800','connecting-pass-frommajoir',1),(24,'Connecting Pass from Jungfraujoch Beginning point','connecting-pass-from-jungfraujoch-beginning-point','5000','connecting-pass-from-begining',1),(25,'Swiss Travel Pass','swiss-travel-pass','5000','swiss-travel-pass',1),(26,'Laucerne-Interlaken Express','laucerne-interlaken-express','5000','laucerne-interlaken-',1),(27,'Interlaken-Lucerne Express','interlaken-lucerne-express','1234','interlaken-lucerne-e',1),(28,'Interlaken-Montreux Express','interlaken-montreux-express','4000','interlaken-montreux-',1),(29,'Montreux-Interlaken Express','montreux-interlaken-express','5000','montreux-interlaken-',1),(30,'Gelmerbahn steepest funicular','gelmerbahn-steepest-funicular','5000','gelmerbahn-steepest-',1),(31,'Stanserhorn CabriO Cable car','stanserhorn-cabrio-cable-car','50000','stanserhorn-cabrio-c',1),(32,'Stoosbahn','stoosbahn','80200','stoosbahn',1),(33,'Swiss Smart Travel Pass','swiss-smart-travel-pass','7855','swiss-smart-travel-p',1);
/*!40000 ALTER TABLE `lw_lrgnd_travel_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_travel_reductions`
--

DROP TABLE IF EXISTS `lw_lrgnd_travel_reductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_travel_reductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reduction` text,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_travel_reductions`
--

LOCK TABLES `lw_lrgnd_travel_reductions` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_travel_reductions` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_travel_reductions` VALUES (1,'Swiss Smart Travel Pass',1),(2,'Swiss Travel Pass',1),(3,'Half Fair card(Halbtax)',1),(4,'Junior Card',1);
/*!40000 ALTER TABLE `lw_lrgnd_travel_reductions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lw_lrgnd_user_primary_information`
--

DROP TABLE IF EXISTS `lw_lrgnd_user_primary_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lw_lrgnd_user_primary_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `first_name` text,
  `last_name` text,
  `dob` date DEFAULT NULL,
  `email` text,
  `gender` text,
  `streat_address` text,
  `zip_code` varchar(45) DEFAULT NULL,
  `city` text,
  `country` text,
  `traveling_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `remark` text,
  `is_active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lw_lrgnd_user_primary_information`
--

LOCK TABLES `lw_lrgnd_user_primary_information` WRITE;
/*!40000 ALTER TABLE `lw_lrgnd_user_primary_information` DISABLE KEYS */;
INSERT INTO `lw_lrgnd_user_primary_information` VALUES (1,'Mr.','Nirosh','Randimal','2004-09-10','nirorandimal@gmail.com','female','awdawdawd','12000','Kalutara','Sri lanka','2019-09-17','2019-09-27','wqsgszgszgzsgrzsrgzsrgzsrgzsg',1),(2,'Mr.','Nirosh','Randimal','2004-09-10','nirorandimal@gmail.com','female','awdawdawd','12000','Kalutara','Sri lanka','2019-09-17','2019-09-27','wqsgszgszgzsgrzsrgzsrgzsrgzsg',1),(3,'Mr.','Nirosh','Randimal','2004-09-10','nirorandimal@gmail.com','female','awdawdawd','12000','Kalutara','Sri lanka','2019-09-17','2019-09-27','wqsgszgszgzsgrzsrgzsrgzsrgzsg',1),(4,'Mr.','Nirosh','Randimal','2004-09-10','nirorandimal@gmail.com','female','awdawdawd','12000','Kalutara','Sri lanka','2019-09-17','2019-09-27','wqsgszgszgzsgrzsrgzsrgzsrgzsg',1),(5,'Mr.','aefaef','aefaefaef','2004-09-08','nirorandimal@gmail.com','male','aeaefaef','12344','srgsrgsrg','asrgsrgsrg','2019-09-25','2019-09-26','esfsefsefsefsefsef',1),(6,'Mr.','aefaef','aefaefaef','2004-09-18','nirorandimal@gmail.com','male','aeaefaef','12344','srgsrgsrg','asrgsrgsrg','2019-09-25','2019-09-26','esfsefsefsefsefsef',1),(7,'Mr.','aefaef','aefaefaef','2004-09-18','nirorandimal@gmail.com','male','aeaefaef','12344','srgsrgsrg','asrgsrgsrg','2019-09-25','2019-09-26','esfsefsefsefsefsef',1),(8,'Mr.','aefaef','aefaefaef','2004-09-18','nirorandimal@gmail.com','male','aeaefaef','12344','srgsrgsrg','asrgsrgsrg','2019-09-25','2019-09-26','esfsefsefsefsefsef',1),(9,'Mr.','aefaef','aefaefaef','2004-09-18','nirorandimal@gmail.com','male','aeaefaef','12344','srgsrgsrg','asrgsrgsrg','2019-09-25','2019-09-26','esfsefsefsefsefsef',1),(10,'Mr.','sefsef','sefsef','2004-09-08','nirorandimal@gmail.com','male','sefsefse','ssefsef','sefsefs','sfsefsef','2019-09-30','2019-10-01','sfsfse',1),(11,'Mrs.','sefsef','sefsef','2004-09-18','nirorandimal@gmail.com','male','sefsefse','ssefsef','sefsefs','sfsefsef','2019-09-30','2019-10-01','sfsfse',1),(12,'Mr.','aefaef','aefaef','2004-09-01','nirorandimal@gmail.com','male','aefaefaef','12000','kalutara','Sri Lanka','2019-10-01','2019-09-30','aefaefaef',1),(13,'Mr.','aefaef','aefaef','2004-09-18','nirorandimal@gmail.com','male','aefaefaef','12000','kalutara','Sri Lanka','2019-10-01','2019-09-30','aefaefaef',1),(14,'Mr.','aefaef','aefaef','2004-09-18','nirorandimal@gmail.com','male','aefaefaef','12000','kalutara','Sri Lanka','2019-10-01','2019-09-30','aefaefaef',1),(15,'Mrs.','awdawdawd','wadawd','2004-09-14','nirorandimal@gmail.com','male','awdawd','123','ereaf','awdawdawd','2019-10-02','2019-09-23','awdawdawd',1),(16,'Mr.','awdawdawd','wadawd','2004-09-18','nirorandimal@gmail.com','male','awdawd','123','ereaf','awdawdawd','2019-10-02','2019-09-23','awdawdawd',1),(17,'Mr.','awdawdawd','wadawd','2004-09-18','nirorandimal@gmail.com','male','awdawd','123','ereaf','awdawdawd','2019-10-02','2019-09-23','awdawdawd',1),(18,'Mrs.','awdawdawd','awdawdaw','2004-09-02','nirorandimal@gmail.com','male','awdawd','awdawd','awdawd','awdawdawd','2019-09-30','2019-09-26','awdawdawdawd',1),(19,'Mr.','awdawdawd','awdawdaw','2004-09-18','nirorandimal@gmail.com','male','awdawd','awdawd','awdawd','awdawdawd','2019-09-30','2019-09-26','awdawdawdawd',1),(20,'Miss','awdawdawd','awdawdaw','2004-09-18','nirorandimal@gmail.com','male','awdawd','awdawd','awdawd','awdawdawd','2019-09-30','2019-09-26','awdawdawdawd',1),(21,'Mr.','awdawd','awdawdawd','2004-09-09','nirorandimal@gmail.com','male','awdawd','awdawd','awdawd','awdawd','2019-10-01','2019-09-25','awdawdawd',1),(22,'Mr.','aefaefaef','aefaefaef','2004-09-09','nirorandimal@gmail.com','male','aefaef','aefaef','aefaef','aefaefaef','2019-09-26','2019-10-01','aefaefaef',1),(23,'Mr.','aefaefaef','aefaefaef','2004-09-18','nirorandimal@gmail.com','male','aefaef','aefaef','aefaef','aefaefaef','2019-09-26','2019-10-01','aefaefaef',1),(24,'Mrs.','aefaefaef','aefaefaef','2004-09-18','nirorandimal@gmail.com','male','aefaef','aefaef','aefaef','aefaefaef','2019-09-26','2019-10-01','aefaefaef',1),(25,'Mr.','aefaefaef','aefaefaef','2004-09-18','nirorandimal@gmail.com','male','aefaef','aefaef','aefaef','aefaefaef','2019-09-26','2019-10-01','aefaefaef',1),(26,'Mr.','aefaefaef','aefaefaef','2004-09-18','nirorandimal@gmail.com','male','aefaef','aefaef','aefaef','aefaefaef','2019-09-26','2019-10-01','aefaefaef',1),(27,'Mr.','aefaefaef','aefaefaef','2004-09-17','nirorandimal@gmail.com','male','awdawdawd','awdawd','awdawd','awdawdawd','2019-09-25','2019-09-30','awdawdawdawdawdawd',1),(28,'Mr.','awdawd','awdawdawd','2004-09-18','nirorandimal@gmail.com','male','awdawdawd','awdawd','awdawd','awdawdawd','2019-09-26','2019-10-03','awdawdawdawdawd',1),(29,'Mr.','wadawd','awdawdawd','2004-09-18','nirorandimal@gmail.com','male','awdawd','awdawd','awdawd','awdawdawd','2019-10-04','2019-10-02','awdawdawdawd',1),(30,'Mr.','aefaef','aefaefaef','2004-09-16','nirorandimal@gmail.com','male','awdawd','awdawd','awdawd','awdawdawd','2019-10-02','2019-09-30','awdawdawdawdawd',1),(31,'Mrs.','aefaef','aefaefaef','2004-09-19','nirorandimal@gmail.com','male','awdawd','awdawd','awdawd','awdawdawd','2019-10-02','2019-09-30','awdawdawdawdawd',1),(32,'Mr.','aefaef','aefaefaef','2004-09-19','nirorandimal@gmail.com','male','awdawd','awdawd','awdawd','awdawdawd','2019-10-02','2019-09-30','awdawdawdawdawd',1);
/*!40000 ALTER TABLE `lw_lrgnd_user_primary_information` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-19 10:56:38
