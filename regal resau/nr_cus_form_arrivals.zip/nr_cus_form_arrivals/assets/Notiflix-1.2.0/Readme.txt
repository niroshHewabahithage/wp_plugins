Thanks for downloading Notiflix. 
 ----- 
Notiflix is a pure JavaScript library for client-side non-blocking notifications that make your web projects much better. 
 ----- 
Notiflix is fully customizable. You may visit the Documentation page to learn how. 
 ----- 
https://www.notiflix.com/
https://www.notiflix.com/documentation