//@authur Nirosh Randimal

jQuery.noConflict();
(function ($) {
    $(function () {
        $(document).ready(function () {
            console.log(document.cookie);
            $("#currency_change").change(function () {
                console.log(this.value);
                var res = JSON.parse(this.value);
                console.log();
                document.cookie = "currency_value=" + res.curreny_value + "";
                document.cookie = "currency_symbol=" + res.currency_sysmbol + "";
                console.log(document.cookie);
                location.reload();
            });
        });

    });
})(jQuery);


