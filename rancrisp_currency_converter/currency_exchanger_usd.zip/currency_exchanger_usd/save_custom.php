<?php

global $wpdb;
$table_name = $wpdb->prefix . "custom_currencies";
print_r($_POST);
