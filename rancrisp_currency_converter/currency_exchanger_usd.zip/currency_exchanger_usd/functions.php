<?php

/*
  Plugin Name: Price Manager Free
  Plugin URI: http://weblankan.com
  Description: Coverts the lkr price values to the predefined currency values
  Version: 1.0
  Author: Nirosh Randimal
  Author URI: www.linkedin.com/in/nirosh-randimal-331598146
  License: GPL2
 */

global $me_db_version;
global $folder;
global $site_url;
global $uri_segnemt;
global $limit;
global $table_name;
global $rncrp_db_version;

$rncrp_db_version = '1.0.0';
$folder = 'rancrisp';
$uri_segnemt = 5;
$limit = 5;
global $wpdb;
$table_name = $wpdb->prefix . "custom_currencies";

function _nr_rancrsp_currency_authentication_init() {
    global $table_name;
    global $rncrp_db_version;
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
                    `currency_id`  int(11) NOT NULL AUTO_INCREMENT ,
                `currency_name`  varchar(255) NOT NULL ,
                `currency_symbol`  varchar(255) NOT NULL ,
                `exchange_rate` varchar(100) NOT NULL,
                PRIMARY KEY (`currency_id`)
	) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta($sql);
}

register_activation_hook(__FILE__, '_nr_rancrsp_currency_authentication_init');
register_activation_hook(__FILE__, '_nr_rancrsp_currency_my_activation_func');

function _nr_rancrsp_currency_my_activation_func() {
    file_put_contents(__DIR__ . '/my_loggg.txt', ob_get_contents());
}

function function_custom_currency() {
    wp_enqueue_style('_nr_rancrsp-main', plugins_url('assets/css/main.css', __FILE__));
    wp_enqueue_script('_nr_rancrsp-currency-selector', plugins_url("assets/js/main.js", __FILE__), array('jquery'), 1.1, true);

    wp_localize_script('_nr_rancrsp_category-view', 'the_ajax_script', array('ajaxurl' => admin_url('admin-ajax.php')));
    global $wpdb;
    global $table_name;
    $result = $wpdb->get_results("SELECT * FROM $table_name order by currency_id desc");


    echo '<select id="currency_change" name="currency_change" class="form-control">';
    ?>

    <?php

    $value_set = "";
    $x = '';
    foreach ($result as $__value) {
        $x++;
        $value_set = json_encode(array("currency_sysmbol" => $__value->currency_symbol, "curreny_value" => $__value->exchange_rate));
        if ($__value->exchange_rate == $_COOKIE['currency_value']) {
            echo " <option selected='true' value='" . $value_set . "'>" . $__value->currency_name . "- (" . $__value->currency_symbol . ")</option>";
        } else {
            echo "<option value='" . $value_set . "'>" . $__value->currency_name . "- (" . $__value->currency_symbol . ")</option>";
        }
    }

    echo '</select>';
}

add_action('custom_currency_hook', 'function_custom_currency', 7);

//function return_custom_price($price, $product) {
//    if (!is_cart()) {
//        $currency_multiplier = "";
//        if (isset($_COOKIE['currency_value'])) {
//            $currency_multiplier = $_COOKIE['currency_value'];
//        }
//        global $post, $blog_id;
//        $price = get_post_meta($post->ID, '_regular_price');
//        $post_id = $post->ID;
//        if ($_COOKIE['currency_value'] == 1 || $_COOKIE['currency_value'] = "") {
//            $price = ($price[0]);
//        } else {
//            $price = ($price[0] / $currency_multiplier);
//        }
//        return $price;
//    } else {
//        return $price;
//    }
//}
//
//add_filter('woocommerce_get_price', 'return_custom_price', 10, 2);





// action function for above hook

/**
 * Adds a new top-level page to the administration menu.
 */
add_action('admin_menu', 'extra_post_info_menu');

function extra_post_info_menu() {

    $page_title = 'Customizing custom currency for woocommerce products';
    $menu_title = 'Custom Currency';
    $capability = 'manage_options';
    $menu_slug = 'custom-currency-values';
    $function = 'my_custom_menu_page';
    $icon_url = 'dashicons-translation';
    $position = 78;

    add_menu_page($page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position);
}

function my_custom_menu_page() {
    //esc_html_e( 'Admin Page Test', 'textdomain' );  
    wp_enqueue_style('_nr_rancrisp_ecom-boostrap', plugins_url('assets/bootstrap/css/bootstrap.min.css', __FILE__));
    wp_enqueue_style('_nr_rancrisp_ecom-main', plugins_url('assets/css/main.css', __FILE__));
    wp_enqueue_script('_nr_rancrisp_ecom-boostrap', plugins_url("assets/bootstrap/js/bootstrap.min.js", __FILE__), array('jquery'), 1.1, true);

    global $wpdb;
    $table_name = $wpdb->prefix . "custom_currencies";
    $result = $wpdb->get_row("SELECT * FROM $table_name order by currency_id desc");

    $div = '';
    $div .= "<div class='row'>";
    $div .= "<div class='col-lg-10 col-md-10 col-sm-10 col-xs-10 set_class_style'>";
    $div .= "<h3>Custom Currency Manager</h3>";
    $div .= "<p>Manages the Custom Currency values for the woocommerce<p>";
    $div .= "</div>";
    $div .= "</div>";
    $div .= "<div class='row'>";
    $div .= "<div class='col-lg-4 col-md-4 col-sm-12 colxs-12'>";
    if ($result) {
        $div .= "<form class='set_form_styles' action='" . esc_url(admin_url('admin-post.php')) . "' method='POST'>";
        $div .= "<label class='label_styles'>" . $result->currency_name . " - " . $result->currency_symbol . "</label>";
        $div .= "<input type='hidden' name='action' value='update-currency_value'>";
        $div .= "<input type='hidden' name='currency_id' value='" . $result->currency_id . "'>";
        $div .= "<input type='number' class='form-control class_input_currency' name='custom_cur_value' value='" . $result->exchange_rate . "'>";
        $div .= "<input type='submit' class='btn btn-block btn-info btn_01' name='' value='Submit Values'>";
        $div .= "</form>";
    }
    $div .= "<div>";
    $div .= "</div>";
    $div .= "</div>";
    $div .= "</div>";
    echo $div;
}

add_action('admin_post_update-currency_value', 'nr_pr_custom_currency');

function nr_pr_custom_currency() {
    global $wpdb;
    $table_name = $wpdb->prefix . "custom_currencies";
    $id_currency = "";
    $currency_value = "";
    if (isset($_POST['currency_id'])){
        $id_currency=$_POST['currency_id'];
    }
    if($_POST['custom_cur_value']){
        $currency_value=$_POST['custom_cur_value'];
    }
    $result = $wpdb->query("UPDATE $table_name SET exchange_rate='$currency_value' WHERE currency_id=$id_currency");

    header('Location: ' . get_site_url() . '/wp-admin/admin.php?page=custom-currency-values');
}
