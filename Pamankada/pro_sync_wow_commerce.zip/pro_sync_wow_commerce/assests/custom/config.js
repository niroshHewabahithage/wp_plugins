
$(document).ready(function () {
    
    window.alert(55);
});