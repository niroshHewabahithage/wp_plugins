(function ($) {
            $(function () {
                $(document).ready(function () {
                    var url = 'http://80.241.213.7:7085/ShoppingCartAPI/GetProductCategories';
                    $.ajax({
                        url: url,
                        data: '{"ApiKey":"cGFtYW5rYWRhQDEyMzQ="}',
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            //debugger;
                            alert("Failed to save request (" + XMLHttpRequest.status + "). Error : " + XMLHttpRequest.statusText)
                        },

                        success: function (data) {
                            //debugger;

                            console.log(data);
                        },
                        type: 'POST',
                        async: false
                    });
                });
            });
        })(jQuery);