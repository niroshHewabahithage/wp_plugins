<?php

/*
  Plugin Name: Pro Sync
  Plugin URI: http://weblankan.com
  Description: Order management system that keep syncing and make direct contact with the local systems
  Version: 1.0
  Author: Nirosh Randimal
  Author URI: www.linkedin.com/in/nirosh-randimal-331598146
  License: GPL2
 */
//declaring global variables

global $me_db_version;
global $folder;
global $site_url;
global $url_segments;
global $limit;
global $table_name;
global $oms_db_version;
global $wpdb;
global $product;
//setting global value to the pre deckared varibles
$oms_db_version = '1.0.0';
$folder = 'pamankada';
$url_segments = 5;
$limit = 5;
$table_name = $wpdb->prefix . 'oms_orders_logs';

//$site_url = 'http://pec.webtesteti.com/';
//install plugin
function nr_order_plg_install() {
    ini_set('displa_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    global $table_name;
    global $oms_db_version;
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
                `id`  int(11) NOT NULL AUTO_INCREMENT ,
                `order_id` VARCHAR(45),
                `refrence_id` VARCHAR(55),
                `name` VARCHAR(150),
                `address` VARCHAR(5000),
                `phone_number` VARCHAR(45),
                `date_created` datetime,
                `description`  varchar(500),
                `expire`  datetime,
                `status`  int(2),
                `other`  text,
                PRIMARY KEY (`id`)
	) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    add_option('oms_db_version', $oms_db_version);
}

register_activation_hook(__FILE__, 'nr_order_plg_install');
register_activation_hook(__FILE__, 'nr_order_plg_my_activation_func');

#error log or Success log

function nr_order_plg_my_activation_func() {
    file_put_contents(__DIR__, '/my_logg.txt', ob_get_contents());
}

//cansatisfy Order
function add_the_date_validation($passed, $product_id) {
    $passed = FALSE;
    $quentity = '';
    if (isset($_POST['quantity'])) {
        $quentity = $_POST['quantity'];
    } else {
        $quentity = 1;
    }
    $productmeta = new WC_Product($product_id);

    $sku = $productmeta->sku;

    wp_enqueue_script('sweetAlerts');

    $result_array = [];

    wp_enqueue_script('ajax-script', plugins_url('assests/custom/myjs.js', __FILE__), array('jquery')
    );
    $data_string = '{"ApiKey":"cGFtYW5rYWRhQDEyMzQ=","Lines":[{"ProductCode":"' . $sku . '","Qty":' . $quentity . '}]}';

//print_r($data_string);
    $ch = curl_init('http://95.216.118.186:7085/ShoppingCartAPI/CanSatisfyOrder');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json')
            //'Content-Length: ' . strlen($data_string))
    );



    $result = curl_exec($ch);
    $result_array = json_decode($result);
  //  print_r($result_array);
    if ($result_array->Success) {
        if ($result_array->CanSatisfy == 1) {
            $passed = TRUE;
        } else {
            $passed = FALSE;
            wc_add_notice(__('Out of Stock', 'woocommerce'), 'error');
            echo '<script>alert("Out of Stock");</script>';
        }
    } else {
        $passed = FALSE;
        wc_add_notice(__('' . $result_array->Description . '', 'woocommerce'), 'error');
        echo '<script>alert("' . $result_array->Description . '");</script>';
    }
    return $passed;
}

add_filter('woocommerce_add_to_cart_validation', 'add_the_date_validation', 10, 5);

add_action('woo_niro_trigger_tempory_order_api', 'is_phone');

function is_phone($push_data) {

    global $woocommerce;
    $items = $woocommerce->cart->get_cart();
    $set_content = "";
    $product_array = "";

    $set_content .= "<table>"
            . "<thead>"
            . "<tr>"
            . "<th>Item Code</th>"
            . "<th>Item Name</th>"
            . "<th>Quentity</th>"
            . "<th>Unit Price(LKR)</th>"
            . "</tr>"
            . "</thead>";
    foreach ($items as $item => $values) {
        $_product = wc_get_product($values['data']->get_id());
        $price = get_post_meta($values['product_id'], '_price', true);
        $set_content .= "<tr>"
                . "<td>" . $_product->get_sku() . "</td>"
                . "<td>" . $_product->get_title() . "</td>"
                . "<td>" . $values['quantity'] . "</td>"
                . "<td>" . $price . "</td>"
                . "</tr>";

        $product_array .= '{"ProductCode":"' . $_product->get_sku() . '","Qty":' . $values['quantity'] . ',"Rate":' . $price . '},';
    }
    //echo $product_array;
    //print_r($push_data);

    $set_content .= "<tr>"
            . "<td colspan=3>Net Total</td>"
            . "<td colspan=1>" . $push_data['subtotal'] . " LKR </td>"
            . "</tr></table>";


    echo $set_content;
    $selectedTime = time("H:i:s");

//    echo $selectedTime;
    $endTime = strtotime("+15 minutes", $selectedTime);
    // echo date('h:i:s', $endTime);
    $today = date("Y-m-d H:i:s");
    //  echo date_default_timezone_get();

    $data_string = '{"ApiKey":"cGFtYW5rYWRhQDEyMzQ=","Date": "' . $today . '","RefNo": "' . $push_data['order_id'] . '","Name": "' . $push_data['name'] . '","Address": "' . $push_data['Address'] . '","PhoneNo": "' . $push_data['phone_number'] . '","Lines":[' . $product_array . ']}';
    //print_r($data_string);

    $ch = curl_init('http://95.216.118.186:7085/ShoppingCartAPI/PlaceTempOrder');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json')
            //'Content-Length: ' . strlen($data_string))
    );

    $result = curl_exec($ch);
    $result_array = json_decode($result);
    // print_r($result_array);
    session_start();
    $_SESSION["ref_number"] = $result_array->RefNo;
    if ($result_array->Success) {
        global $wpdb;
        global $table_name;
        $date = date("Y-m-d H:i:s");
        $currentDate = strtotime($date);
        $futureDate = $currentDate + (60 * 5);
        $formatDate = date("Y-m-d H:i:s", $futureDate);
//        echo $formatDate;
        $data = array(
            "order_id" => $push_data['order_id'],
            "refrence_id" => $result_array->RefNo,
            "name" => $push_data['name'],
            "address" => $push_data['Address'],
            "phone_number" => $push_data['phone_number'],
            "date_created" => date("Y-m-d H:i:s"),
            "description" => "tempory_order",
            "expire" => $formatDate,
            "status" => 0,
            "other" => "afbahefjaehefjh"
        );
        $wpdb->insert('wp_oms_orders_logs', $data);
        wc_add_notice(__('Successfully Created tempory order in local system with the Reference number:' . $result_array->RefNo . ''), 'success');
    } else {

        wc_add_notice(__('' . $result_array->Description . '', 'woocommerce'), 'error');
    }
// your function's body above, and if error, call this wc_add_notice
//    wc_add_notice(__('Your phone number is wrong.'), 'success');
}

add_action('woo_niro_trigger_tempory_order_api_paypal', 'is_cuss');

function is_cuss($push_data) {

    global $woocommerce;
    $items = $woocommerce->cart->get_cart();
    $set_content = "";
    $product_array = "";

    $set_content .= "<table>"
            . "<thead>"
            . "<tr>"
            . "<th>Item Code</th>"
            . "<th>Item Name</th>"
            . "<th>Quentity</th>"
            . "<th>Unit Price(LKR)</th>"
            . "</tr>"
            . "</thead>";
    foreach ($items as $item => $values) {
        $_product = wc_get_product($values['data']->get_id());
        $price = get_post_meta($values['product_id'], '_price', true);
        $set_content .= "<tr>"
                . "<td>" . $_product->get_sku() . "</td>"
                . "<td>" . $_product->get_title() . "</td>"
                . "<td>" . $values['quantity'] . "</td>"
                . "<td>" . $price . "</td>"
                . "</tr>";

        $product_array .= '{"ProductCode":"' . $_product->get_sku() . '","Qty":' . $values['quantity'] . ',"Rate":' . $price . '},';
    }
    //echo $product_array;
    //print_r($push_data);

    $set_content .= "<tr>"
            . "<td colspan=3>Net Total</td>"
            . "<td colspan=1>" . $push_data['subtotal'] . " LKR </td>"
            . "</tr></table>";


    echo $set_content;
    $selectedTime = time("H:i:s");

//    echo $selectedTime;
    $endTime = strtotime("+15 minutes", $selectedTime);
    // echo date('h:i:s', $endTime);
    $today = date("Y-m-d H:i:s");
    //  echo date_default_timezone_get();

    $data_string = '{"ApiKey":"cGFtYW5rYWRhQDEyMzQ=","Date": "' . $today . '","RefNo": "' . $push_data['order_id'] . '","Name": "' . $push_data['name'] . '","Address": "' . $push_data['Address'] . '","PhoneNo": "' . $push_data['phone_number'] . '","Lines":[' . $product_array . ']}';
    //print_r($data_string);

    $ch = curl_init('http://95.216.118.186:7085/ShoppingCartAPI/PlaceTempOrder');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json')
            //'Content-Length: ' . strlen($data_string))
    );

    $result = curl_exec($ch);
    $result_array = json_decode($result);
    // print_r($result_array);
    session_start();
    $order = wc_get_order($order_id);
    $_SESSION["ref_number"] = $result_array->RefNo;
    $_SESSION["order_id"] = $order_id;
    $_SESSION["total_price"] = $push_data['subtotal'];
    if ($result_array->Success) {
        global $wpdb;
        global $table_name;
        $date = date("Y-m-d H:i:s");
        $currentDate = strtotime($date);
        $futureDate = $currentDate + (60 * 5);
        $formatDate = date("Y-m-d H:i:s", $futureDate);
//        echo $formatDate;
        $data = array(
            "order_id" => $push_data['order_id'],
            "refrence_id" => $result_array->RefNo,
            "name" => $push_data['name'],
            "address" => $push_data['Address'],
            "phone_number" => $push_data['phone_number'],
            "date_created" => date("Y-m-d H:i:s"),
            "description" => "tempory_order",
            "expire" => $formatDate,
            "status" => 0,
            "other" => "afbahefjaehefjh"
        );
        $wpdb->insert('wp_oms_orders_logs', $data);
        wc_add_notice(__('Successfully Created tempory order in local system with the Reference number:' . $result_array->RefNo . ''), 'success');
        static $status = 1;
        return TRUE;
    } else {
        $status = FALSE;
        wc_add_notice(__('' . $result_array->Description . '', 'woocommerce'), 'error');
    }
// your function's body above, and if error, call this wc_add_notice
//    wc_add_notice(__('Your phone number is wrong.'), 'success');
}

add_action("payment_status", "confirmation_function");

function confirmation_function() {
    global $site_url;
//    echo get_site_url();
//    print_r("session" . $_SESSION["order_id"]);
    $error_msg = '<h2 style="text-align: center">Sorry Your Payment Has Failed Try Again in a while</h2>'
            . '<center>'
            . '<img src="' . get_site_url() . '/wp-content/uploads/2018/10/379854-PCNGBL-658.png" alt="warning" width="16%" style="margin: 0 0 22px 0">'
            . '</center>'
            . '<p style="text-align: center">Payment has been failed for  ' . $_SESSION['order_id'] . '</p>'
            . '<p style="text-align: center">Your Order Has Cancelled</p>'
            . '<h3 style="text-align: center;margin: 0 0 15px;">#' . $_GET['unidue'] . '</h3>';

    $success_msg = '<h2 style="text-align: center">Your payment Successfull</h2>'
            . '<center>'
            . '<img src="' . get_site_url() . '/wp-content/uploads/2018/10/16711-NQRDON.png" alt="warning" width="16%" style="margin: 0 0 22px 0">'
            . '</center>'
            . '<p style="text-align: center">Payment has been Successfull for  ' . $_SESSION['order_id'] . '</p>'
            . '<h3 style="text-align: center;margin: 0 0 15px;">#' . $_GET['unidue'] . '</h3>';

    if ($_GET['webxpay']) {
        if ($_GET['status'] == "0") {

            echo $error_msg;
            $data_string = '{"ApiKey":"cGFtYW5rYWRhQDEyMzQ=","OrderRefNo": "' . $_SESSION["order_id"] . '","Reason": "Payment Failed"}';
            //print_r($data_string);

            $ch = curl_init('http://95.216.118.186:7085/ShoppingCartAPI/CancelOrder');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json')
                    //'Content-Length: ' . strlen($data_string))
            );
            $result = curl_exec($ch);
            $result_array = json_decode($result);
            // print_r($result_array);
            if ($result_array->Success) {
                $_SESSION["order_id"] = "";
            } else {
                
            }
            echo '<p style="background: #ff606054; padding: 1% 0 1% 1%; color: #000; border-radius: 6px; margin: 0 0 10px 0;">' . $result_array->Description . '</p>';
        } else if ($_GET['status'] == "1") {
            echo $success_msg;
            $order = new WC_Order($_SESSION["order_id"]);
            //print_r($order);
            //print_r($order->order_key);
            // print_r($order->payment_method . " " . $order->payment_method_title);
            $data_string = '{"ApiKey": "cGFtYW5rYWRhQDEyMzQ=","OrderRefNo": "' . $_SESSION["order_id"] . '","TempRefNo": "' . $_SESSION["ref_number"] . '","Payment":{"Method":"Card","PaymentRefNo":"' . $order->order_key . '","Amount":' . $_SESSION["total_price"] . '}
    
}';
            //print_r($data_string);

            $ch = curl_init('http://95.216.118.186:7085/ShoppingCartAPI/ConfirmOrder');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json')
                    //'Content-Length: ' . strlen($data_string))
            );
//print_r($result_array);
            $result = curl_exec($ch);
            $result_array = json_decode($result);
//            print_r($result_array);
//            print_r($result_array->Description);
            if ($result_array->Success) {
                echo 'nirosh';
                echo '<p style="background: #60ff9154; padding: 1% 0 1% 1%; color: #000; border-radius: 6px; margin: 0 0 10px 0;">' . $result_array->Description . '</p>';
            } else {
                echo '<p style="background: #ff606054; padding: 1% 0 1% 1%; color: #000; border-radius: 6px; margin: 0 0 10px 0;">' . $result_array->Description . '</p>';
            }
        } else {

            echo $error_msg;
            $data_string = '{"ApiKey":"cGFtYW5rYWRhQDEyMzQ=","OrderRefNo": "' . $_SESSION["order_id"] . '","Reason": "Payment Failed"}';
            //print_r($data_string);

            $ch = curl_init('http://95.216.118.186:7085/ShoppingCartAPI/CancelOrder');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json')
                    //'Content-Length: ' . strlen($data_string))
            );
//print_r($result_array);
            $result = curl_exec($ch);
            $result_array = json_decode($result);
            // print_r($result);
            echo '<p style="background: #ff606054; padding: 1% 0 1% 1%; color: #000; border-radius: 6px; margin: 0 0 10px 0;">' . $result_array->Description . '</p>';
            if ($result_array->Success) {
                $_SESSION["order_id"] = "";
            } else {
                
            }
        }
    } else {
        echo $error_msg;

        $data_string = '{"ApiKey":"cGFtYW5rYWRhQDEyMzQ=","OrderRefNo": "' . $_SESSION["order_id"] . '","Reason": "Payment Failed"}';
        //print_r($data_string);

        $ch = curl_init('http://95.216.118.186:7085/ShoppingCartAPI/CancelOrder');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json')
                //'Content-Length: ' . strlen($data_string))
        );
//print_r($result_array);
        $result = curl_exec($ch);
        $result_array = json_decode($result);
        //wc_add_notice(__('', 'woocommerce'), 'error');
        echo '<p style="background: #ff606054; padding: 1% 0 1% 1%; color: #000; border-radius: 6px; margin: 0 0 10px 0;">' . $result_array->Description . '</p>';
        if ($result_array->Success) {
            $_SESSION["order_id"] = "";
        } else {
            
        }
    }
    echo "<div class='row'>"
    . "<div class='col-md-4'></div>"
    . "<div class='col-md-4 col-sm-12'>"
    . "<a href='http://192.168.8.15/pama_2/'><button class='btn btn-block btn-warning' style='padding: 3%; font-size: 18px; margin: 3% 0px;'>Go to Home</button></a>"
    . "</div>"
    . "<div class='col-md-4'></div>"
    . "</div>";
    return;
}

function paypal_tempary_order() {
    echo 'lol';
}

add_action('payment_success_paypal_success', "paypal_order_confirmation", 10, 3);
add_action('payment_success_paypal_failed', "paypal_order_cancel", 10, 3);

function paypal_order_cancel($order_id) {
    echo $error_msg;
//    print_r($order_id);
    session_start();
//    print_r($_SESSION);
//    print_r($_SESSION["ref_number"]);
    $data_string = '{"ApiKey":"cGFtYW5rYWRhQDEyMzQ=","OrderRefNo": "' . $order_id . '","Reason": "Payment Failed"}';
    //print_r($data_string);

    $ch = curl_init('http://95.216.118.186:7085/ShoppingCartAPI/CancelOrder');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json')
            //'Content-Length: ' . strlen($data_string))
    );
    $result = curl_exec($ch);
    $result_array = json_decode($result);
//    print_r($result_array);
    if ($result_array->Success) {
        $_SESSION["order_id"] = "";
        wc_add_notice(__('Order Cacellation Process Successfull:' . $result_array->Description . ''), 'success');
        echo '<p style="background: #88fc654d; padding: 1% 0 1% 1%; color: #000; border-radius: 6px; margin: 0 0 10px 0;">Order Cancellation Process Successful</p>';
    } else {
        echo '<p style="background: #ff606054; padding: 1% 0 1% 1%; color: #000; border-radius: 6px; margin: 0 0 10px 0;">' . $result_array->Description . '</p>';
//        wc_add_notice(__('Order Cacellation Process Suucessfull:' . $result_array->Description . ''), 'error');
    }

    print_r($result_array);
}

function paypal_order_confirmation($order_id,$order_total) {
    $order = new WC_Order($_SESSION["order_id"]);
//    print_r($order);
//    print_r($order_id);
//    print_r($order->order_key);/
//    print_r($order->payment_method . " " . $order->payment_method_title);
    session_start();
//    print_r($_SESSION);
//    print_r($_SESSION["ref_number"]);
    $data_string = '{"ApiKey": "cGFtYW5rYWRhQDEyMzQ=","OrderRefNo": "' . $order_id . '","TempRefNo": "' . $_SESSION["ref_number"] . '","Payment":{"Method":"Card","PaymentRefNo":"' . $_SESSION["ref_number"] . '","Amount":' . $_SESSION["total_price"] . '}
    
}';
//    print_r($data_string);

    $ch = curl_init('http://95.216.118.186:7085/ShoppingCartAPI/ConfirmOrder');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json')
            //'Content-Length: ' . strlen($data_string))
    );
//    print_r($result_array);
    $result = curl_exec($ch);
    $result_array = json_decode($result);
    if ($result_array->Success) {
        $_SESSION["order_id"] = "";
        wc_add_notice(__('Order Cacellation Process Successfull:' . $result_array->Description . ''), 'success');
        echo '<p style="background: #88fc654d; padding: 1% 0 1% 1%; color: #000; border-radius: 6px; margin: 0 0 10px 0;">Order Confirmation Process Successful</p>';
    } else {
        echo '<p style="background: #ff606054; padding: 1% 0 1% 1%; color: #000; border-radius: 6px; margin: 0 0 10px 0;">' . $result_array->Description . '</p>';
//        wc_add_notice(__('Order Cacellation Process Suucessfull:' . $result_array->Description . ''), 'error');
    }


//    print_r($result_array);
}
